"""Necessary representation test for the carrier identification in Claude K.

Does not exclude a 16-real-fermion D8 source whose Spin(10) half-spinor
carrier appears later in a Ramond/composite sector. The tested identification
is specifically elementary real field labels = original complex D5 S+.
"""
from collections import Counter
from itertools import product
import json

weights = {w for w in product((-1, 1), repeat=5)
           if sum(x < 0 for x in w) % 2 == 0}
conjugate = {tuple(-x for x in w) for w in weights}
if len(weights) != 16 or weights & conjugate:
    raise RuntimeError("Unexpected D5 half-spin weight set")

result = {
    "scope": "D5 half-spinor weights in doubled integral coordinates",
    "complex_dimension": len(weights),
    "negation_closed": weights == conjugate,
    "intersection_with_conjugate": len(weights & conjugate),
    "uniform_Cartan_doubled_charges": dict(sorted(Counter(map(sum, weights)).items())),
    "necessary_real_structure_test": "FAIL for a 16-real-dimensional representation with this same Spin10 action",
    "possible_distinct_construction_retained": "D8 vector16 real restricts as (10,1)+(1,6); its Ramond spinor128 contains the complex (16,4) carrier and conjugate",
    "fundamental_source_excluded": False,
    "new_general_mathematical_result": False,
}
print(json.dumps(result, ensure_ascii=False, indent=2))
