# Was diese Rechnung jetzt klärt

Die aktuelle TFPT Formel kann den vollständigen inneren Feldoperator aus der gegebenen Randquelle zurücklesen. Dafür braucht sie keine zusätzlich ausgesuchte Kreisfrequenz. Der Schritt, der das möglich macht, stand bereits in der ursprünglichen Verifikation: Nach der Rückrechnung wird der bezüglich der inneren Chiralität ungerade Anteil genommen.

Bildlich enthält die Randquelle zwei überlagerte Spuren. Eine beschreibt die Bewegung entlang des Kreises. Die andere beschreibt die inneren Felder. Die ursprüngliche Auslese trennt beide. Sie erhält auch den Majoranaterm und die vollständige Änderung des Yukawateils.

```text
Geometrische Bewegung + innere Felder
                 ↓
      gemeinsame Quelle beider Ränder
                 ↓
      ursprüngliche logarithmische Auslese
                 ↓
  gerader Anteil           ungerader Anteil
  Kreisbewegung            innerer Feldoperator
```

Für die geprüfte Quellenklasse ist die Trennung verlustfrei. Wenn die geometrischen Daten und die Normierung erhalten bleiben, lässt sich daraus wieder die ganze gemeinsame Randquelle aufbauen. Auch ihre gemeinsamen Feldkorrelationen bleiben dadurch bestimmt. Der Beweis gilt für glatte örtlich veränderliche Felder; sie müssen mit der Bewegung entlang des Kreises nicht vertauschen.

Die tatsächliche Rechenkette wurde mit den vorhandenen Operatoren ausgeführt und unabhängig geprüft. Die automatische Prüfung begann bei der ganzen verdoppelten Quelle und verwendete anschließend die originale Rückrechnung. Sie hat keine passende Ersatzformel eingesetzt. Die Prüfwerte sind Kontrollwerte und keine neu hergeleiteten physikalischen Massen.

## Was das für die Suche verändert

Eine bloße Rückkopplung dieser Auslese erzeugt keine bestimmten Feldwerte. Sie funktioniert wie das Speichern und anschließende Öffnen einer Datei: Dass der Inhalt wieder erscheint, bestimmt nicht, welcher Inhalt ursprünglich geschrieben wurde. Mit passender Normierung kommt jedes eingesetzte Feld unverändert zurück. Eine genetische Suche, die nur dieses Zurückkommen belohnt, kann deshalb keine bevorzugten Yukawakopplungen entdecken.

Dieser konkrete Suchkreis ist mathematisch geklärt. Die nächste Rechnung muss die ursprüngliche Erzeugung der gemeinsamen Quelle betreffen: Welche tatsächliche Trägerabbildung und welche Wirkung legen ihren Inhalt fest? Die aktuelle Formel benennt dazu eine Kompression auf den Träger. Ihre Gleichsetzung mit der jetzt geprüften Auslesekette und ihre physikalische Normierung sind noch nicht hergeleitet.

Die vollständige fundamentale Lösung liegt damit noch nicht vor. Neu geschlossen ist ein präziser Anschluss zwischen der vorhandenen ganzen Randquelle und der vollständigen ursprünglichen Feldauslese. Die Bedingungen für ihren physikalischen Ursprung, ihre Reflexion und die tatsächliche Zeitwirkung bleiben sichtbar und werden durch die Rückrechnung nicht stillschweigend vorausgesetzt.

## Belege

- [Vollständige Herleitung des ursprünglichen Lesers](/Users/stefanhamann/Projekte/tfpt-theoryv4/experiments/theory-contracts/tfpt-unified-source-derivation-20261029/aps_source_review/CURRENT-CARRIER-ODD-READER-WHOLE-SOURCE.txt)
- [Verlustfreier Rückweg und vollständige Fixpunktklassifikation dieser Schleife](/Users/stefanhamann/Projekte/tfpt-theoryv4/experiments/theory-contracts/tfpt-unified-source-derivation-20261029/aps_source_review/LOSSLESS-CARRIER-ODD-READER-DICTIONARY-REVIEW.txt)
- [Automatische Prüfung des tatsächlichen Aufrufpfads](/Users/stefanhamann/Projekte/tfpt-theoryv4/experiments/theory-contracts/tfpt-unified-source-derivation-20261029/aps_source_review/CURRENT-ODD-READER-CHECK.json)

Im gemeinsamen Atlas gespeichert und zurückgelesen: Revision `78cb490f463288e79048a123`.
