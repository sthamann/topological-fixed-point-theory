# Zwei Verwechslungen sind entschieden

Stand vom 29. Oktober 2026. Die vollständige physikalische TFPT Herleitung ist weiterhin offen. Die folgenden Prüfungen verändern konkret, welche Lösungswege noch tragen.

**Die geometrische Windung bleibt erhalten.** Claude wollte die ursprüngliche Windung mit einer Drehung des endlichen Higgsoperators gleichsetzen. Die ursprünglichen Texte behandeln hier verschiedene Objekte. Anschaulich: Die Art, wie zwei Stoffstücke zusammengenäht sind, ist etwas anderes als eine Drehung eines Pfeils auf dem Stoff.

Für den vorhandenen Higgsoperator ist die Rechnung jetzt für seine ganze vorgegebene Familie entschieden. Sein Determinant besitzt bei festen invertiblen Yukawamatrizen und nirgends verschwindendem Higgsfeld eine konstante Phase. Er wickelt sich also nicht um den Nullpunkt. Weitere Zufallsversuche können daran nichts ändern. Die geometrische Verklebung mit Grad eins und der dazu gegebene normale Spinoperator bleiben davon unberührt. Die Behauptung, ein neutrales Feld könne grundsätzlich keine Windung besitzen, ist durch einen ausdrücklichen Gegenfall widerlegt.

**Ein Wärmefilter liefert noch keine physikalische Zeit.** Ein Filter kann hohe Frequenzen unterdrücken und dabei mathematisch positiv sein. Das genügt nicht für die spezielle Positivität, die beim Übergang von gespiegelten Randdaten zu einem Quantenraum gebraucht wird. Schon zwei positive Zeitpunkte liefern einen exakten Gegenfall. Für die ganze untersuchte Klasse stetiger, bei null differenzierbarer, skalarer und zeitlich verschiebungsinvarianter Korrelationen gilt sogar: Nur eine konstante Korrelation erfüllt beide Positivitätsforderungen.

Das schließt die vorhandenen gültigen Zeitentwicklungen nicht aus. Ein echter positiver Energieoperator liefert weiterhin positive gespiegelte Korrelationen. Auch der übliche freie Feldkern mit seiner Spitze bei Zeit null bleibt zulässig. Entscheidend ist, den Hilfsparameter einer Spektralrechnung und die tatsächliche Spiegelungszeit auseinanderzuhalten.

Die beiden Ergebnisse sind mit Originalstellen und unabhängiger analytischer Prüfung im gemeinsamen Atlas gespeichert. Bereits gelöste E₈, Clock, Clifford und Randquellenanschlüsse bleiben erhalten. Die Klassensätze ersetzen weitere Suchläufe innerhalb ihrer Voraussetzungen.

Claude hat die Originaltexte jetzt direkt als lesbaren Text erhalten, nachdem sein Recherchewerkzeug die Paperdateien nicht öffnen konnte. Grok erhält die neue Frage, ob die tatsächliche ursprüngliche Admissibilitätsoperation eine gemeinsame Quelle trägt. Ihre äußeren Hilfsgrade dürfen dabei nicht ohne Abbildung zu physischen Teilchen erklärt werden. Gemini liefert bislang keinen abgeschlossenen Bericht.

Der nächste tragende Schritt bleibt eine konkrete gemeinsame Operatorregel aus dem Original, die bosonische Felder und fermionische Antworten samt Zustand, Spiegelung und Zeit tatsächlich erzeugt. Die beiden gerade geprüften Gleichsetzungen können diese Regel nicht ersetzen.
