# Was jetzt tatsächlich weiter ist

Die beiden Randseiten liefern im geprüften endlichen Ausschnitt eine berechenbare gemeinsame Antwort. Stell dir zwei gekoppelte Messstellen vor: Wir haben jetzt auch ihre gemeinsamen Ausschläge berechnet. Vier reelle Kombinationen haben eine positive Antwort. Das wurde unabhängig mit den wirklichen Fermionregeln geprüft.

Dabei haben wir zwei Fehler vermieden. Man muss alle inneren Komponenten mitzählen und die adjungierten Felder mitnehmen. Eine einzelne verschwindende Formel bedeutet sonst fälschlich, dass gar nichts schwankt.

Außerdem waren wir bei einem Teil der alten Theorie bereits weiter: Die Auslese aus der Monodromie ist seit einer alten Verifikation vorhanden. Auch die Worttabelle ist unter ihren festgelegten Bedingungen eindeutig. Beides ist jetzt wieder mit dem aktuellen Weg verknüpft. Diese Teile müssen wir nicht neu erfinden.

Ein konkreter Anschluss gelingt: Der alte skalare Leser erkennt einen exakt bestimmten Anteil der neuen gemeinsamen Antwort. Dafür stimmen die tatsächlichen Operatoren überein.

Offen ist die vollständige ursprüngliche Erzeugungsregel. Wir verfolgen dafür den in den Papern vorhandenen ganzen Quellenoperator und seine Compilergewichte weiter. Er muss erklären, wie diese berechneten Beiträge tatsächlich in das gemeinsame Feldsystem eingehen. Das ist noch kein bewiesener Gesamtabschluss.

Die neuen Belege, die engen Ausschlüsse und die wiedergefundenen alten Abschlüsse sind im gemeinsamen Atlas gespeichert und nach dem Speichern zurückgelesen. Claude und Grok arbeiten im bestehenden Chat mit genau diesen Korrekturen weiter.
