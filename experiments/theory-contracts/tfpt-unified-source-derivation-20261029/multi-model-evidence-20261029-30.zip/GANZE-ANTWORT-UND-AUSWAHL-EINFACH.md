# Was diese Prüfung verändert

Eine vereinfachte Ansicht der neuen Antwort stimmt beim ersten kleinen Ausschlag. Wenn man das ganze System betrachtet, fehlen dieser Ansicht bereits beim nächsten Rechenschritt echte Beiträge. Wir haben diese Beiträge jetzt exakt berechnet. Die vereinfachte Ansicht bleibt als einzelne Auslese nützlich und ersetzt nicht den ganzen Feldoperator.

Auch die Rückwärtsrichtung war schon in der ursprünglichen Theorie enthalten. Sie muss nicht als neuer Baustein erfunden werden.

Der ursprüngliche Zulässigkeitsoperator ist ebenfalls konkret vorhanden. Bildlich ist er ein Sieb: Er trennt zulässige von unzulässigen Bauteilen. Seine Strafwerte sind für alle durchgelassenen Bauteile null. Diese Werte allein sagen deshalb nicht, mit welcher Stärke die zugelassenen Bauteile gekoppelt werden. Dafür nennt das Paper weitere Daten, insbesondere Transportcounts und Trägerlabels.

Die weitere Rechnung verfolgt die tatsächliche Verwendung dieser Daten oder den direkten Weg von der ursprünglichen Wirkung zum ganzen Transferoperator. Der vollständige bereits gegebene Zustand mit seinen Feldprodukten, beiden Rändern, Reflexion und Zeit bleibt erhalten.

Außerdem haben wir einen echten Fehler im Atlas behoben: Ein aktiver Folgeauftrag verlangte noch Rechnungen für fünf Eingaben, die längst vollständig vorlagen. Jetzt verweist er auf das vorhandene Ergebnis und den tatsächlich nächsten Herkunftsschritt.

Die vollständige fundamentale Erzeugungsregel ist damit noch nicht bewiesen. Die neue exakte Gegenprüfung verhindert eine falsche Gleichsetzung und erhält die echte ganze Antwort für die weitere Herleitung.
