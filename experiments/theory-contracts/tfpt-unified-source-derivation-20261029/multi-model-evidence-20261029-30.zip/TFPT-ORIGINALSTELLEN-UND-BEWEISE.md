# TFPT Gesamtbild, Originalstellen und aktuelle Beweise

Originale, bedingte Nachweise und offene Herkunftsfragen werden hier gemeinsam zur unabhängigen Prüfung übergeben. Die lokale offene Aufgabenformulierung darf selbst hinterfragt werden. Die Berichtsaussagen sind prüfbare Behauptungen. Keine globale Herleitung ist bereits durch die Anzahl der Checks bewiesen. Vollständige öffentliche Paper: https://www.fixpoint-theory.com/papers und https://www.fixpoint-theory.com/ . Lokale Dateipfade sind Quellenbezeichner, keine über das Web erreichbaren Dateien.

## .codex/context/tfpt-gesamtkontext.md

Original SHA256 662be98c30cd492b2433440c6ed86fe5856141dab1b93d20466bbc6bef034741; Zeilen 1 bis 130.

```text
1: # TFPT — übergeordneter Gesamtkontext
2: 
3: Stand 2026-09-17 · lokaler Korpus v5.4 · Quellen-HEAD `66b91e40e245569f06ab440ead80f446c9be0ee5`; zusätzliche Arbeitsdateien separat. Dieser Kontext ist die hierarchische Einstiegskarte, kein Ersatz für die Beweise. Bei TFPT/Universalraum zuerst vollständig lesen, dann gezielt Originalstellen prüfen. Nicht auf eine jüngste Modellstudie oder eine einzelne offene Lücke reduzieren.
4: 
5: **Leitsatz:** TFPT ist ein verzahnter, selbstkonsistenter Compiler-Kandidat für das dimensionslose Gerüst fundamentaler Physik: ein kleiner geometrisch-algebraischer Ursprung → Träger/Familien → E₈-Abschluss → Flavor, α, Gravitation/Kosmologie → Rückprüfung desselben Ursprungs. Clocks, Zahlkörper, Darstellungen und Fixpunkte sind miteinander verbunden. Die physische gemeinsame Ausführung ist von der exakten Compiler-Struktur zu unterscheiden.
6: 
7: **Leseschlüssel:** **A** = gesetzter Ursprung/Schnittstelle; **E** = exakte Struktur unter Voraussetzungen; **N** = numerischer/formelbezogener Befund; **C** = zusätzliche physikalische Identifikation; **O** = fehlende Herleitung. Die Ledgeranzeige `[E]` umfasst teils auch Numerical; deshalb keine numerische Prüfung als allgemeinen Beweis ausgeben.
8: 
9: ## 0. Entwicklung und Gesamtarchitektur
10: 
11: 0.1 **Entwicklungslinie:** Möbius-/Nahtgeometrie und Hierarchiekaskade → P1/P2-Compiler → Anker- und E₈-Bootstrap → gemeinsame Rand-/Modularstruktur → Ursprung von physischer Dynamik und Auslesung → Universalraum als möglicher gemeinsamer Träger beziehungsweise als tieferer Ursprung, dessen Auslesung TFPT ist.
12: 
13: 0.2 **Zwei verzahnte Mechanismen:** (I) diskreter Abschluss: Träger → Darstellungen/Gitter → Standardmodell- und Flavorgerüst; (II) Randantwort: c₃ → φ₀, α, Skalenrelationen und geometrischer/gravitationaler Kanal. Gravitation ist in dieser Architektur ein Ausgabekanal der Randstruktur. Die Ergebnisse liefern Rückbedingungen an die Ausgangsdaten.
14: 
15: 0.3 **Vier Geltungsebenen:** algebraischer Compiler; bedingte Rand-/IR-Physik; dimensionale und Amplitudenanker; physische Transferschnittstellen. Selbstkonsistenz ist ein System gemeinsam erfüllter Bedingungen. Der Beweisgraph bleibt azyklisch: Annahmen dürfen sich nicht durch ihre eigenen Folgen begründen.
16: 
17: ## 1. Ursprung: Naht, vier Marken, Anker
18: 
19: 1.1 **P1 [A]:** orientierte Naht Σ, primitiver reflexionspositiver Randkern, Einheitswindung und Normierung c₃ = 1/(8π). **P2 [A]:** fünfteilige Trägerschnittstelle g = 5 mit 3+2-Zerlegung. Das sind strukturierte Voraussetzungen, nicht nur zwei Dezimalzahlen.
20: 
21: 1.2 **Komprimierung [E/C]:** parabolischer Anker a = (1,1,2), Bündeltyp O(−2)⊕O(−1)²; e₁=4, e₂=5, e₃=2; Potenzsummen pₙ=2+2ⁿ. Somit c₃=1/(2e₁π), g=e₂; Differenzen pₙ₊₁−pₙ=2ⁿ erzeugen die Verdopplungsleiter. p₁p₂p₃=240, p₄−p₃=8, Summe 248.
22: 
23: 1.3 **Geometrische Rücklesung:** μ₄={1,i,−1,−i}; vierpunktierte P¹ hat H₁≅Z³ → Familienrang 3; Riemann–Roch für Grad-4-Divisor gibt h⁰=5 → Trägerzahl. Möbius-/Doppeldeckung, Z₂, vier Marken und τ=i strukturieren die Naht. Das Wort „Möbius“ für Band/Deckung und für die Möbiusgruppe ist kein automatischer physikalischer Identifikationsbeweis.
24: 
25: 1.4 **Auswahlgrenze:** alternative komprimierte Präsentationen „a+π“, „vier Marken+Symmetrielift+π“, „E₈-Fixpunkt+π“ erklären interne Starrheit innerhalb ihrer Voraussetzungen. Sie sind keine voraussetzungslose Erzeugung der Welt. Die Ledger-Eingaben P1/P2 bleiben als solche markiert; Identifikation des physischen Randes und Kontinuum müssen tragen.
26: 
27: ## 2. Compiler und E₈-Abschluss
28: 
29: 2.1 **Compiler = konkrete Übersetzungsregeln**, nicht bloß Zahlensuche: Rand-/Trägerdaten → Operatoren, Ladungen, Gitter, Phasen, Spektren → bestimmte Auslesungen. Gleiche Zahl oder Dimension reicht nicht; Abbildungen müssen Komposition, Adjunktion, Gruppenwirkung und Markierungen respektieren.
30: 
31: 2.2 **Träger:** S⁺=Λ^even C⁵, dim=1+10+5=16, Halbspinor von Spin(10)/D₅. **Familie:** A₃/su(4), Rang 3. **Verklebung:** disc(D₅)=disc(A₃)=Z₄; q(D₅)=5/4, q(A₃)=3/4, Summe=2; passender Index-4-Überverband hat det=(4·4)/4²=1 → positives gerades unimodulares Rang-8-Gitter E₈ [E].
32: 
33: 2.3 **E₈ als Abschluss-/Prüfobjekt:** Rang 8, 240 Wurzeln, Lie-Dimension 248; nicht einfach die physische Eichgruppe. Verzweigung: (45,1)⊕(1,15)⊕(16,4)⊕(16̄,4̄)⊕(10,6). Weitere Schnitte E₆×A₂, E₇×A₁, A₄×A₄ usw. sind gegenseitige Strukturprüfungen, keine zusätzlichen unabhängigen experimentellen Bestätigungen.
34: 
35: 2.4 **Bootstrap:** rangfüllender familienhaltiger D_g+A_m-Abschluss und Norm-/Diskriminantenbedingungen wählen D₅+A₃ in ihrer Vergleichsklasse; μ²−5μ+4=0 → nichttrivial μ=4, g=5. Pascal 2^g=g²+g+2 wählt g=5; Rangfüllung g+3=8 und passende Coxeterrelation prüfen dieselbe Architektur. Rückschleife g=5 → E₈ → h=30=2·3·5 → Trägerzahl 5. „Eindeutig“ immer mit Auswahlklasse lesen.
36: 
37: ## 3. Standardmodell und Flavor
38: 
39: 3.1 **Algebraisches SM-Gerüst [E unter Eingaben]:** 3+2, Hyperladung −1/3 auf Farb-, +1/2 auf schwachen Plätzen; SU(3)×SU(2)×U(1), kY=5/3, sin²θW=3/8 an der Trägerskala. Eine Familie: Q:(3,2)₁/₆, uᶜ:(3̄,1)₋₂/₃, dᶜ:(3̄,1)₁/₃, L:(1,2)₋₁/₂, eᶜ:(1,1)₁, νᶜ:(1,1)₀. 16 Komponenten, Anomaliesummen passen. N_fam=3; 48 Familienkomponenten; gewählte Verdopplung/finite Spektraltripel-Darstellung 96. Ein Higgs im gewählten minimalen Auslesevertrag.
40: 
41: 3.2 **Flavor-Operatoren:** auf dem Z³-Familiengitter Q,K,R,L; det=(3,4,8,20), Produkt 1920=|W(D₅)|. Residuen, Windungen, Minoren/Plücker-Daten statt unabhängiger Yukawa-Exponenten. R mit Zeilen (1,3,0),(1,5,2),(2,5,3), det R=8. L_{fj}=r_{fj}+6n_{fj}; ΣL=40, mit Higgs 41=10b₁.
42: 
43: 3.3 **Gemeinsamer Seed:** φ₀=1/(6π)+48c₃⁴=1/(6π)+3/(256π⁴)≈0,05317195; λY=λC=√[φ₀(1−φ₀)]≈0,22437624. Massenleiter m̂_fj=(v_geo/√2) λY^{L_fj} Λ_fj; ausgewertete Zweige auch (v_geoπ/√2)c_fj φ₀^{k_fj}. Leptonen c=(16/7,4/3,7/6), k=(5,3,2). Quellmassen sind keine automatisch fertigen Polmassen; Λ/Normierung, Renormierung und Schwellen bleiben sichtbar.
44: 
45: 3.4 **Grenze:** Ladungs-/Darstellungsableitung und numerische Flavor-Ausgaben sind substanziell; dieselben Resultate sind noch keine konstruierte wechselwirkende chirale 3+1D-Quantentheorie. Spiegelentkopplung, Maß, physische Yukawa-/Neutrinoauswahl und gemeinsamer Ursprung sind gesonderte Aufgaben.
46: 
47: ## 4. α und die Fixpunkte
48: 
49: 4.1 **Elektromagnetische Rückkopplung:** δ_top=48c₃⁴, q(α)=δ_top exp(−2α), φ_s(α)=1/(6π)+q(1−q)^(−5/4). Schließung:
50: 
51: `F(α)=α³−2c₃³α²−(4/5)·41·c₃⁶·log[1/φ_s(α)]=0`.
52: 
53: Die Gleichung verwendet dieselbe Nahtnormierung, Z₂, Trägernorm 5/4 und das Flavor-/Higgsbudget 41. Positive Zielwurzel α⁻¹=137,0359992168407…; Existenz/Eindeutigkeit und Zahlwert innerhalb des Gleichungsvertrags prüfen v3/Intervallargumente [E/N]. Ward-/Determinantenursprung und Identifikation mit physischem Thomson-α sind zusätzliche Aussagen [C/O]. α im Exponenten q ist die kleine Kopplung; kosmologische exp(−2/α)-Ausgabe verwendet ihren Kehrwert.
54: 
55: 4.2 **Drei Fixpunkte nicht vermischen:** (a) algebraischer Bootstrap/Abschluss der diskreten Daten; (b) selbstkonsistente α-Gleichung; (c) stationärer Zustand/Attraktor eines festgelegten Transferoperators. Ein algebraisch eindeutiger Abschluss muss nicht ein eingefrorener physischer Weltzustand sein.
56: 
57: 4.3 **Transfer-Attraktor:** unter den positiven/gapped Voraussetzungen T mit Spektrum {1,(2/3)⁶,(1/3)⁶}, Lücke Δ=6 log(3/2), eindeutige stationäre Richtung und geometrische Annäherung. Ein fixer führender Modus und nichttriviale übrige Moden existieren gemeinsam. Der Satz bestimmt das Verhalten des ausgewählten T; er ist kein voraussetzungsloser Selektor von T.
58: 
59: ## 5. Ineinandergreifende Clocks — unverzichtbarer Kern
60: 
61: 5.1 **Coxeter:** h(E₈)=30=2·3·5; Z₃₀≅Z₅×Z₆. Fünferstruktur des Trägers und Sechserstruktur aus Familie×Deckung; gemeinsame Wiederkehr nach 30. Acht primitive Phasen, Exponenten {1,7,11,13,17,19,23,29}, φ(30)=8; vier konjugierte Ebenen. Algebra exakt; physische gemeinsame Uhr zusätzlich.
62: 
63: 5.2 **Galois-Getriebe:** μ₄ ist KEIN Unterzyklus der 30er-Drehung (4∤30), sondern wirkt als Automorphismus ihrer Phasendaten. (Z/30)×≅Z₄×Z₂; Trägerseite Gal(Q(ζ₅))≅Z₄. Explizit **G C₅ G⁻¹=C₅², G⁴=I**. μ₄ greift also in die Fünfer-Clock ein, statt nur neben ihr zu laufen. Deckung/Divisor, Galois, Diskriminante und Simple-Current-Verklebung haben passende Z₄-Strukturen; abstrakter Isomorphismus und physisch kanonische Identifikation unterscheiden.
64: 
65: 5.3 **Familien- und Compiler-Clock:** Ordnung-3-Familienaktion σ, zentraler Vierteldreher J; konkrete G₃₁-Darstellung c=Jσ mit c¹²=I, σ=c⁴, J=c⁹. G₃₁ hat Ordnung 46080, 60 Reflexionen und Grade (8,12,20,24). Compiler-c ist nicht die reguläre Springer-Clock gleicher Ordnung: tatsächliche Konjugationsklasse und Orbitstruktur prüfen. Matrixordnung, projektive Ordnung, beobachtbare Konjugationsperiode und physische Dauer sind verschieden.
66: 
67: 5.4 **Resummierte/Relaxations-Clock:** Raten r(n)=−6 log(1−n/3), n=0,1,2; zugehörige Überlebenswerte 1,2/3,1/3. Sechs Schritte erzeugen beide Lücken 6log(3/2),6log3. Lazy-pair-Regel stay/hop/leak=(1/2,1/6,1/3) innerhalb treuer Leiter-, Paritäts- und Positivitätsannahmen. Nariai-/Quantenclock-, Born-Quadrat-, Entropie-/Flächen- und Determinantenketten v104–v147 verbinden diese Raten mit bedingten physikalischen Lesarten; ihre semiclassische/maßtheoretische Herkunft nicht mit exakter Ratenarithmetik gleichsetzen.
68: 
69: 5.5 **Gemeinsame Herkunftsbilder:** binär-ikosaedrische Gruppe 2I/McKay; Brieskorn x²+y³+z⁵, Milnorzahl 8, E₈-Monodromie. Quadratische Facetten i, √−3, √5; Normen aus (3,2) liefern 7,13,55, aus (5,4) die 41. Das sind miteinander verknüpfte Darstellungen desselben Zahlengerüsts, keine Liste unabhängiger Wunder.
70: 
71: 5.6 **Physische Zeitgrenze:** kontinuierliche Sektoruhr, RG-Skala, inverse Temperatur und diskreter Clock-Schritt nicht gleichsetzen. F_transfer besitzt eine gemeinsame Kontraktionsform; die geprüften Viersektor-Clock-/Thermal-Time-Gleichsetzungen scheitern unter ihren konkreten Voraussetzungen (v723/v724/v777). Keine universelle Widerlegung relationaler Zeit. Periodische Anzeigen benötigen für mehrere Umläufe weitere Zählinformation.
72: 
73: ## 6. Quantenwelt, Rand und Universalraum
74: 
75: 6.1 **Endliche Quantenstruktur:** E₈ über Z[i]/Hamming-Code; L/(1+i)L≅F₂⁴ mit symplektischer Paarung und Verfeinerung. Zwei-Qubit-Pauli/Clifford-Darstellung, 60 Strahlen in 15 orthogonalen Viererkontexten. Kontexte sind nicht dieselbe Darstellung wie 15 Pauli-Punkte. Clifford-/Stabilizer-Struktur allein liefert keine allgemeine universelle Quantenrechnung.
76: 
77: 6.2 **Rand-QFT-Kandidat:** (AΣ,ωΣ,ΔΣ,ρ,A_F,H_F,D_F,J,γ,S_rel); modulare/KMS-Struktur, CAR/Clifford, finite Algebra H_L⊕H_R⊕M₄(C), KO-6/96D-Spektraltripel; Dirac-/Yukawa- und Cutoff-Lesarten aus Kovarianz/KMS. Kummer/K3 verknüpft Naht, 16er-Träger und E₈-Gitter. SEAM.EQUIV: roher Rand = holomorphes (E₈)₁-Netz; Modell-/Satzanschlüsse sind vorhanden, unbedingte physische Identifikation und Grenzwerte bleiben getrennt.
78: 
79: 6.3 **Dynamik vor Universalraum:** Tⁿ-Relaxation, exp(t log T)-Markovprozess und exp(−itH)-Quantenentwicklung sind unterschiedliche Ebenen. Endliche unitäre/Kollisions-/kontinuierliche Erweiterungen existieren im Korpus; dieselbe Populationsregel lässt verschiedene kohärente Ausführungen zu. Wahl von Ausführung, Zustand, Umgebung, Zugriff und gemeinsamer Feldgrenze ist die Ursprungsfrage.
80: 
81: 6.4 **Ursprungsimpuls Universalraum:** Die vielen TFPT-Darstellungen könnten Ansichten eines gemeinsamen einfacheren Zusammenhangs sein. Zwei Richtungen getrennt prüfen: TFPT → operationelle Vervollständigung; tieferer Universalraum → TFPT als Auslesung. Gleicher momentaner Schatten genügt nicht für gleiche Zukunft: Phasen, Korrelationen, Aufzeichnungen und erlaubte Fortsetzungen tragen Information.
82: 
83: 6.5 **Bisherige genaue Grenzen:** 16 reale Majoranas/256D-Fockraum, H70, QWZ-Streifen, Rotor/CAR-Parent, Ω∈Λ⁴C⁴ und spätere native Fockbanken sind verschiedene Konstruktionen. Zulässige Übertragung verlangt Operator-/Ladungs-/Zustandsabbildungen. Vollständiges Wegprotokoll kann Interferenz zerstören; Kompression muss zukünftige Antworten bewahren. Reversible endliche Ausführung hat Rekurrenz. Zusätzlicher Oszillator/Mischer/Kopplungswert ist erst dann Ursprungsfortschritt, wenn seine Auswahl folgt.
84: 
85: ## 7. Ausgaben/Vorhersagen: gemeinsame Herkunft, verschiedene Status
86: 
87: Historischer eingefrorener Formelstand, kein aktueller experimenteller Gesamtfit:
88: 
89: | Bereich | Zentrale Ausgabe | Einordnung |
90: |---|---|---|
91: | EM | α⁻¹=137,03599921684… | Wurzel bestimmt; physischer Ursprung/Transfer gesondert |
92: | CKM | λC=0,224376; s₂₃=0,043428; s₁₃=0,003765; δ≈68,65° | gemeinsamer Seed, führende Holonomie-/Flavorlesart |
93: | PMNS | sin²θ₁₂=0,306747; sin²θ₁₃=0,023108; δ=240°; symmetrisch θ₂₃=45° | Registry unterscheidet bedingt/core/assigned; vollständige Neutrinodynamik offen |
94: | Leptonen | m̂μ/m̂τ=(8/7)φ₀; m̂e/m̂μ=(12/7)φ₀² | Quellverhältnisse; Polmassen benötigen begründeten Transfer |
95: | Quarks | 55/117; (34/47)/φ₀; (3/26)/φ₀² | Auslesung von Plücker-Daten; einheitliches Massenschema erforderlich |
96: | Kosmologie | β=φ₀/(4π) rad≈0,242435°; Ωb=(1−1/4π)φ₀≈0,048941 | bedingte gemeinsame Rand-/Budgetlesart; Ωb≠Ωb h² |
97: | Inflation | Mscal/M̄=c₃^(7/2); n_s=1−2/N*, r=12/N*² | R+R²-Zweig, N*/Reheating extern; N*=50…60 als eingefrorenes Band |
98: | Vakuum/Hierarchien | ρΛ/M̄⁴=3exp(−2/α)/(4π²); führende Wirkungen α⁻¹/5:α⁻¹:2α⁻¹=1:5:10 | Vorfaktoren, Zweigwahl und Maßstab sichtbar halten |
99: 
100: Gravitation: Einstein/Jacobson-Kanal mit c₃⁻¹=8π unter lokalen QFT-/Entanglement-Voraussetzungen; kein automatisch vollständig quantisierter Gravitationsursprung. Interfaces F_transfer: Koide, ηB/Leptogenese, Axionrelikt, m_p/m_e; zusätzliche Anker/RG-/kosmologische Daten, nicht heimlich autonome Compiler-Vorhersagen. Eine dimensionslose Theorie benötigt für Sekunden/GeV eine metrologische Kalibrierung. Unterschiedliche Verwendung von v_geo/Planck-/EW-Skala quellengetreu unterscheiden.
101: 
102: ## 8. Verifikation, Selbstkonsistenz und Evidenz
103: 
104: 8.1 **Aktueller gezählter Bestand:** 1028 eindeutige Module sowohl in `verification/run_all.py` als auch `script_registry.csv`, identische Mengen. Cluster: core 494, em 9, flavor 23, masses 12, neutrinos 14, gravity 7, horizon 22, uwall 12, frontier 251, registry 184. Die „600+“ des Nutzers sind historischer Umfang. Ledger: 1194 Zeilen, 1189 aktive, nicht ebenso viele unabhängige Physikbeweise.
105: 
106: 8.2 **Prüfwege:** Python exakt/symbolisch/numerisch, Gegenbeispiele/Mutationstests, Intervallarithmetik; Wolfram als zweiter Rechenweg (dokumentiert 116 Basis-/368 Erweiterungschecks); Lean für formal kodierte Sätze samt Axiom-Audit; Red Team A–E, Quellenpins, Paper↔Suite↔Ledger-Audit. Diese Wege prüfen ihre jeweiligen Aussagen und Voraussetzungen, nicht automatisch das Gesamtweltbild.
107: 
108: 8.3 **Tatsächlich am 2026-09-17 neu ausgeführt:** `python3 -B verification/verify_quick.py`, Exit 0, 89 Prüfungen, darunter 31 Registry-Locks; sechs Kernmodule v1/v2/v3/v5/v9/v84. Vollsuite/Wolfram/Lean nicht neu ausgeführt. Die im Quick-Output angezeigten Wolfram-/Lean-Zeilen sind Verweise, keine Ausführungsbelege dieses Laufs.
109: 
110: 8.4 **Vorhersageregister:** Freeze 2026-06-09; 16 Hauptwerte, 2 zugewiesene Texturen, 2 bedingte Bänder; 2 weitere Varianten ausdrücklich keine neuen Vorhersagen. „27 falsifizierbare Testflächen“ ist die breitere Korpusangabe, nicht 27 unabhängige Blindvorhersagen. Historisch bekannte Daten werden durch Freeze nicht rückwirkend blind; gemeinsame Seeds erzeugen korrelierte Treffer. Nullmodell-Scores sind keine kalibrierte Gesamtwahrscheinlichkeit für TFPT. Datierte Spannungen/Fehlschläge bewahren, neue Daten separat prüfen.
111: 
112: ## 9. Endpunkt des Gesamtkonstrukts und heutige Aufgabe
113: 
114: 9.1 **Physischer Gesamtabschluss laut Ledger offen:** T1 Ursprung P1/P2/Dimension; T2 tatsächliche E₈-Randtheorie/Grenzwert; T3 gemeinsamer lokaler unitärer 3+1D-Ursprung; T4 chirales SM und Spiegelentkopplung; T5 wechselwirkendes Kontinuum/Lorentz/IR; T6 alle Kopplungen und Neutrinodynamik; T7 masseloser Quantenspin 2/universelle Kopplung; T8 physischer Anfangszustand und gemeinsame Erzeugungsfunktion. Schmale Teilresultate können geschlossen sein, ohne den jeweiligen Gesamtsatz zu schließen.
115: 
116: 9.2 **Unbedingt beides behalten:** TFPT besitzt bereits ein umfangreiches präzises, querverbundenes System. Nicht auf „nur statische Zahlen“ verkürzen. Zugleich keine fehlende physische Herleitung durch das Gewicht der Verifikationssammlung ersetzen.
117: 
118: 9.3 **Nutzerauftrag:** Vom gesamten TFPT-System zur ursprünglichen Dynamiklücke zurückgehen; die ineinandergreifenden Clocks und Selbstkonsistenz ernst nehmen; prüfen, wie eine einfache informationstheoretische Grundwelt aussehen müsste, deren Auslesung TFPT ist. Keine weitere autonome Modellwelt optimieren. Erst die erste zusätzlich gewählte Struktur identifizieren, dann an ihrer Herleitung arbeiten. Einfach und bildlich erklären; komprimieren ohne tragende Beziehungen zu verlieren; bis zum verlangten Ergebnis arbeiten.
119: 
120: ## 10. Originalquellen für gezielte Vertiefung
121: 
122: Repository `/Users/stefanhamann/Projekte/tfpt-theoryv4/`:
123: 
124: - Architektur/Verzahnung: `introduction.tex` (insb. Zwei-Mechanismen-Bild), `tfpt_1_architecture_e8.tex` (P1/P2, α), `origin_theory.tex` (Anker, Clocks/Galois, Attraktor).
125: - SM/Flavor: `tfpt_2_standard_model.tex`; E₈/Bootstrap: `tfpt_3_e8_audit_bootstrap.tex`; Grenzen: `tfpt_4_frontier.tex`, `tfpt_research_contracts.tex`, `docs/OPEN_PROBLEMS.md`.
126: - Maßgebliche Typisierung/Bestand: `verification/status_ledger.csv`, `script_registry.csv`, `run_all.py`, `predictions_frozen.json`; `docs/FALSIFICATION.md`. Ledger und konkrete Voraussetzungen schlagen verkürzte README-Abschlussformulierungen.
127: - Übergang Universalraum: `docs/TFPT_COMPILER_INFORMATION_NEUSTART_2026-09-12.md`, `TFPT_DER_EINFACHE_PROZESS_2026-09-12.md`, `TFPT_COMPILER_UNIVERSALRAUM_PAPER_2026-09-13.md`, `TFPT_UNIVERSALRAUM_INVERSION_2026-09-14.md`.
128: - Auswahl-/Clock-Grenzen: `experiments/theory-contracts/primitive-transfer-selection-20260912/COHERENT_RECORD_SELECTION.md`, `compiler-cone-object-audit/PROCESS_BOUNDARIES.md`, `clock-marking-audit/README.md`, `universalraum-clock-origin-20260915/UPDATE.md`.
129: 
130: **Pflege:** Diese Karte datiert Fakten und trennt sie von Hypothesen. Bei neuen Quellen gezielt aktualisieren; alte Ausschlüsse nur mit ihren Voraussetzungen übernehmen. Keine Behauptung, alle Unterhaltungen oder alle Beweise seien damit vollständig im Kontext.
```

## documents/archive--tfpt-45--source_extracts--01_boundary_kernel_source/sections/001-section-primitive-core-and-carrier-interface-handoff.tex

Original SHA256 7d6e673d99c29d950dc601283cd51c1cc0b113567eeb79c8396fec9c82a02c79; Zeilen 1 bis 377.

```text
1: % Auto-extracted from ../tfpt-42.tex for the TFPT 4.5 clean split.
2: % Source body assigned by the TFPT 4.5 clean split.
3: 
4: % ---- Primitive core and primitive relative spectral dynamics: source lines 849-1305 ----
5: \section{Primitive core and carrier interface handoff}
6: 
7: \subsection{Primitive core and conventions}
8: 
9: We use natural units $c=\hbar=1$. Relative operators are formulated in Euclidean signature and compared through a declared Wick-rotation bridge when Lorentzian language is needed. Higgs fields are denoted by $\Phi$, Hamiltonians by $\mathcal H$, and the cosmological Hubble rate by $\Hhub(t)$; this avoids overloading the letter $H$. Newton's constant is always $G_N$, while $G_{\mathrm{car}}$ is reserved for the internal carrier stabilizer. The seam is denoted by $\Seam$, geometric reflection by $\taudbl$, boundary polarization by $\iC$, carrier polarization by $\epscar$, and word parity by $\varepsilon(w)$.
10: 
11: Here $S\to \widetilde M$ denotes the spinor bundle on the oriented double cover, and by the same symbol we denote its restriction to
12: \[
13: \Xbulk=\widetilde M\setminus\Seam.
14: \]
15: 
16: When color-center notation is needed later, we use multiplicative notation
17: \[
18: z(w)\in\{1,\omega,\omega^2\},
19: \qquad
20: \omega=e^{2\pi i/3}.
21: \]
22: Thus center neutrality means $z(w)=1$.
23: 
24: \[
25: \Tcore^{\mathrm{kin}}
26: :=
27: \bigl(
28: \widetilde M\to M,\ \Seam,\ \taudbl,\ \iC,\ D_{\mathrm{ref}},\ D_{\mathrm{rel}},\ \chiseed
29: \bigr).
30: \]
31: When a chosen almost-commutative factorization
32: $\mathcal H\cong L^2(\widetilde M,S)\otimes\Hint$ is used, $S$ and $\Hint$ refer to that
33: choice and are not part of the kinematic core datum.
34: Here \enquote{relative} always means comparison with a declared reference operator or
35: reference-subtracted action. The canonical admissibility complex is introduced immediately below,
36: while any Bernstein or other spectral test profile is treated only as an analytic realization
37: choice rather than as part of the boundary datum. The technical tables for relative objects,
38: layered closure/benchmark data, and the constants atlas are collected in
39: Appendix~\ref{app:tech} and Appendix~\TFPTxref{app:constants}; they are kept out of the early
40: main-text flow so that the carrier kernel appears before the technical bookkeeping apparatus.
41: 
42: \begin{remark}[Boundary datum versus derived closed structure]
43: The primitive ontology now stops one step earlier. The one-sided boundary datum $\Tbound$
44: contains only one-sided operator data together with the self-adjoint boundary operator
45: $B_\Sigma$. Its Calder\'on projector defines the polarization
46: \[
47: \iC:=2P_C-1.
48: \]
49: From that boundary polarization and the exact double one reconstructs the deck involution
50: $\taudbl$, the physical quotient $M=\widetilde M/\taudbl$, the seam
51: $\Seam=\mathrm{Fix}(\taudbl)$, the reference/relative operator split
52: $(D_{\mathrm{ref}},D_{\mathrm{rel}})$, the primitive seam response
53: $\chiseed=\lambda_1^+(|B_\Sigma|)^{-1}$, and the doubled closed datum
54: $\Tmin^{\mathrm{cl}}$. The seam is therefore no longer primitive ontology but the fixed locus of
55: the deck involution extracted from the one-sided boundary problem.
56: \end{remark}
57: 
58: \subsection{Primitive relative spectral dynamics}
59: 
60: The carrier theorem is not intended to float above an unspecified microscopic dynamics. The
61: starting point is therefore the one-sided boundary datum from which the primitive layer, the
62: derived closed datum, and the canonical admissibility projector are reconstructed before the later
63: closure theorems are invoked.
64: 
65: \begin{definition}[One-sided boundary admissibility datum]
66: \label{def:reduced-theorem-datum}
67: The one-sided boundary admissibility datum is
68: \[
69: \Tbound:=(\mathcal A_+,\mathcal H_+,D_+,J,\Gamma,B_\Sigma)
70: \]
71: with the following built-in admissibility conditions:
72: \begin{enumerate}[label=(\roman*), leftmargin=1.5em, topsep=3pt, itemsep=2pt]
73:     \item $Z(\mathcal A_+)$ is spectrally regular and its Gelfand spectrum is a smooth compact oriented manifold with boundary $M_+$;
74:     \item $B_\Sigma$ is a self-adjoint tangential boundary operator on $\Sigma:=\partial M_+$ compatible with the boundary restrictions of $J$ and $\Gamma$;
75:     \item in a collar neighborhood of $\Sigma$, the Dirac operator has canonical product form
76:     \[
77:     D_+=\gamma_n(\partial_n+B_\Sigma);
78:     \]
79:     \item the boundary collar is reflection-regular so that canonical doubling, the Calder\'on projector, and the admissibility complex are well posed on the same datum.
80: \end{enumerate}
81: \end{definition}
82: 
83: \begin{remark}[Almost-commutative realizations]
84: \label{ass:almost-commutative-factorization}
85: When a factorized realization is useful, one may choose
86: \[
87: \mathcal H\cong L^2(\widetilde M,S)\otimes \Hint,
88: \]
89: with $S\to\widetilde M$ the spinor bundle on the oriented double cover and $\Hint$ a finite
90: internal Hilbert space. This is an analytic realization choice rather than part of the boundary
91: datum.
92: \end{remark}
93: 
94: \begin{theorem}[Doubling, deck involution, and boundary polarization]
95: \label{thm:primitive-datum-from-reduced-datum}
96: \label{thm:primitive-scaffold-from-reduced-datum}
97: Let $\Tbound$ be as above. Let
98: \[
99: \widetilde M:=M_+\cup_{\Sigma} M_+^{\mathrm{op}}
100: \]
101: be the doubled manifold and let
102: \[
103: \taudbl:\widetilde M\to\widetilde M
104: \]
105: be its deck involution. Let $P_C$ be the Calder\'on projector of the APS-realized boundary problem
106: for $D_+$ on $\Sigma$, and define the boundary polarization operator
107: \[
108: \iC:=2P_C-1
109: \]
110: on the Cauchy-data Hilbert space $\mathcal H_{\partial}$.
111: 
112: Then:
113: \begin{enumerate}[label=(\roman*), leftmargin=1.8em, topsep=3pt, itemsep=2pt]
114:     \item the geometric objects are
115:     \[
116:     M=\widetilde M/\taudbl,
117:     \qquad
118:     \Seam=\mathrm{Fix}(\taudbl),
119:     \qquad
120:     \Xbulk=\widetilde M\setminus\Seam;
121:     \]
122:     \item the doubled operator and its even and odd parts are
123:     \[
124:     D=D_+\cup_{\Sigma}D_+^{\mathrm{op}},
125:     \qquad
126:     D_{\mathrm{ref}}:=\frac12\bigl(D+\taudbl^{\ast}D\taudbl^{\ast}\bigr),
127:     \qquad
128:     D_{\mathrm{rel}}:=\frac12\bigl(D-\taudbl^{\ast}D\taudbl^{\ast}\bigr);
129:     \]
130:     \item on boundary Cauchy data the induced reflection $R_{\taudbl}$ satisfies
131:     \[
132:     \operatorname{Ran}(P_C)=\ker(R_{\taudbl}-1),
133:     \qquad
134:     \ker(P_C)=\ker(R_{\taudbl}+1),
135:     \qquad
136:     \iC=R_{\taudbl}.
137:     \]
138: \end{enumerate}
139: Hence the primitive scaffold
140: \[
141: \Tprim^{\mathrm{kin}}
142: :=
143: (\Xbulk,\widetilde M,M,\Seam,\taudbl,\iC,D_{\mathrm{ref}},D_{\mathrm{rel}},\chiseed)
144: \]
145: is derived, not assumed. The derived doubled datum may be recorded as
146: \[
147: \Tmin^{\mathrm{cl}}:=(\mathcal A,\mathcal H,D,J,\Gamma,\taudbl,\iC),
148: \]
149: If one further chooses an almost-commutative factorization
150: \[
151: \mathcal H_{\mathrm{prim}}\cong L^2(\Xbulk,S)\otimes \Hint,
152: \]
153: then $S$ and $\Hint$ refer only to that chosen realization and are not additional
154: reconstruction outputs.
155: \end{theorem}
156: 
157: \begin{proof}
158: Reflection regularity on an exact collar produces the doubled manifold together with the deck
159: involution $\taudbl$. The APS-realized boundary problem has a Calder\'on projector $P_C$ whose
160: range is the Cauchy-data space of interior solutions. On the doubled collar the deck reflection
161: acts on Cauchy data by $R_{\taudbl}$, and the solution space splits into the $\pm1$ eigenspaces of
162: this reflection. Therefore
163: \[
164: P_C=\frac{1+R_{\taudbl}}{2},
165: \qquad
166: \iC=2P_C-1=R_{\taudbl}.
167: \]
168: The formulas for $D_{\mathrm{ref}}$ and $D_{\mathrm{rel}}$ are the even and odd parts of $D$ under
169: the induced involution.
170: \end{proof}
171: 
172: \begin{corollary}[No confusion among the three involutions]
173: Geometric reflection is carried by $\taudbl$, boundary polarization by $\iC$, and the finite
174: carrier split by the restricted involution
175: \[
176: \epscar:=\iC|_{\mathcal H_{\mathrm{car}}}.
177: \]
178: No later theorem may identify these three operators literally; only the displayed restriction and
179: transport maps are allowed.
180: \end{corollary}
181: 
182: The canonical admissibility projector is built in two transparent stages. The primitive stage
183: uses only data already available from $\Tbound$ through the derived boundary polarization $\iC$,
184: namely the seam-even selector on Cauchy data, an APS realization that makes the geometric anchor
185: self-adjoint Fredholm, and the relative operator $D_{\mathrm{rel}}$. The full stage upgrades this
186: primitive projector by the color and determinant projectors that become available only after the
187: carrier theorem of \TFPTxref{sec:minimal-carrier-proof} identifies the color factor and after the
188: compact bosonic index of \TFPTxref{sec:closure-theorems} fixes the determinant involution. The full
189: complex and the upgrade theorem appear once these later inputs are in place; here we close the
190: primitive stage.
191: 
192: \begin{definition}[Primitive admissibility complex and primitive projector]
193: \label{def:admissibility-complex}
194: \label{def:primitive-admissibility-complex}
195: Let the primitive Hilbert space carry only the seam factor and the gap sector accessible from
196: $D_{\mathrm{rel}}$ alone:
197: \[
198: \mathcal H_{\mathrm{prim}}=\mathcal H_{\Seam}\otimes\mathcal H_t,
199: \qquad
200: \mathcal H_{\mathrm{prim}}^{\mathrm{ext}}
201: :=
202: \mathcal H_{\mathrm{prim}}\otimes\Lambda(\eta_\Sigma,\eta_g),
203: \]
204: with primitive seam selector
205: \[
206: P_{\Seam,+}:=\frac{\mathbf 1+\iC}{2}.
207: \]
208: Fix $\epsilon_{\mathrm{adm}}>0$ and let $D_{\mathrm{prim}}$ be the APS-realized restriction of
209: the primitive sector operator to $\mathrm{Ran}(P_{\Seam,+})$, controlled by $D_{\mathrm{rel}}$
210: relative to the geometric anchor. Define the primitive admissibility penalties
211: \[
212: K_\Sigma:=\sqrt{\lambda_\Sigma}\,\frac{\mathbf 1-\iC}{2},
213: \qquad
214: K_g:=\sqrt{\lambda_{\mathrm{gap}}}\,
215: \mathbf 1_{[0,\epsilon_{\mathrm{adm}}^2/4)}\!
216: \bigl(P_{\Seam,+}D_{\mathrm{prim}}^\dagger D_{\mathrm{prim}}P_{\Seam,+}\bigr),
217: \]
218: the primitive admissibility differential
219: \[
220: Q_{\mathrm{prim}}
221: :=
222: \eta_\Sigma^\dagger K_\Sigma
223: +\eta_g^\dagger K_g,
224: \]
225: and the primitive admissibility Laplacian
226: \[
227: \Delta_{\mathrm{prim}}:=\{Q_{\mathrm{prim}},Q_{\mathrm{prim}}^\dagger\}.
228: \]
229: The primitive admissibility projector is the Hodge projector
230: \[
231: \Pprim
232: :=
233: \Pi_{\ker\Delta_{\mathrm{prim}}}.
234: \]
235: \end{definition}
236: 
237: \begin{lemma}[Primitive nilpotency and primitive Hodge projector]
238: \label{lem:admissibility-nilpotency}
239: \label{lem:hodge-admissibility-projector}
240: \label{lem:primitive-admissibility-nilpotency}
241: On the primitive scaffold reconstructed from $\Tbound$,
242: \[
243: Q_{\mathrm{prim}}^2=0,
244: \qquad
245: \Delta_{\mathrm{prim}}
246: =
247: K_\Sigma^2+K_g^2,
248: \qquad
249: \Pprim
250: =
251: \operatorname*{s-lim}_{\beta\to\infty}e^{-\beta(K_\Sigma^2+K_g^2)}.
252: \]
253: In particular $\Pprim$ depends only on $\iC$, the APS realization, and $D_{\mathrm{rel}}$, and
254: is therefore reconstructed from the closed datum at the primitive level. Equivalently,
255: \[
256: \Pprim=P_{\Seam,+}P_{\mathrm{prim,gap}},
257: \qquad
258: P_{\mathrm{prim,gap}}
259: :=
260: \mathbf 1_{[\epsilon_{\mathrm{adm}}^2/4,\infty)}
261: \!\bigl(P_{\Seam,+}D_{\mathrm{prim}}^\dagger D_{\mathrm{prim}}P_{\Seam,+}\bigr).
262: \]
263: \end{lemma}
264: 
265: \begin{proof}[Proof sketch]
266: The auxiliary generators $\eta_\Sigma^\dagger$ and $\eta_g^\dagger$ anticommute, so the square
267: of $Q_{\mathrm{prim}}$ reduces to commutators of $K_\Sigma$ and $K_g$. Both penalties act on
268: commuting sectors of $\mathcal H_{\mathrm{prim}}$, hence the mixed terms vanish and
269: $\Delta_{\mathrm{prim}}=K_\Sigma^2+K_g^2$. The zero-temperature limit projects onto the
270: intersection of seam-even and gapped admissible vectors, which is the factorized form recorded
271: above.
272: \end{proof}
273: 
274: \begin{definition}[Carrier polarization on the finite block]
275: \label{def:carrier-polarization-involution}
276: Let $\mathcal H_{\mathrm{car}}$ denote the finite-dimensional carrier block selected after
277: primitive admissibility compression. Define
278: \[
279: \epscar:=\iC|_{\mathcal H_{\mathrm{car}}},
280: \qquad
281: E_-:=\ker(\epscar+1),
282: \qquad
283: E_+:=\ker(\epscar-1).
284: \]
285: Then the finite carrier decomposition is
286: \[
287: E=E_-\oplus E_+.
288: \]
289: \end{definition}
290: 
291: \begin{remark}[Forward reference to the full admissibility complex]
292: \label{rem:forward-Padm}
293: The full admissibility projector is obtained by upgrading $\Pprim$ with the color center
294: projector $P_{\mathrm{sing}}$ and the determinant involution projector $P_\Theta$, which are
295: available only after the carrier theorem of \TFPTxref{sec:minimal-carrier-proof} identifies the
296: color factor $\mathcal H_c$ and after the compact bosonic index of \TFPTxref{sec:closure-theorems}
297: fixes the determinant involution $Q_\Theta$. The full complex and the explicit upgrade are
298: stated in \TFPTxref{def:full-admissibility-complex,thm:padm-upgrade}; nothing in the present
299: primitive subsection depends on those inputs.
300: \end{remark}
301: 
302: \begin{definition}[Primitive Euclidean action]
303: For any declared spectral test profile $f$, the primitive Euclidean action is the relative
304: spectral seed
305: \[
306: S_{\mathrm{prim}}[\chiseed]
307: :=
308: \tr f\!\left(\frac{D_{\mathrm{rel}}}{\chiseed}\right)
309: -
310: \tr f\!\left(\frac{D_{\mathrm{ref}}}{\chiseed}\right)
311: +\frac{i\pi}{2}\Delta\eta_\Sigma.
312: \]
313: Gauge fixing, ghosts, and carrier-compatible bosonic fluctuations are introduced only after the
314: hard carrier theorem and the canonical admissibility projector are in place. Whenever convenient,
315: the compressed expression $\Padm A\Padm$ may be used as shorthand for matrix elements on the
316: physical admissible sector, but it is not the definition of a local operator net.
317: \end{definition}
318: 
319: \begin{definition}[Physical admissible local net]
320: \label{def:physical-admissible-local-net}
321: Let $\mathfrak A_E(\mathcal O)$ be the Euclidean source algebra generated by local field insertions
322: with test-function support in $\mathcal O$. After the later Osterwalder--Schrader reconstruction,
323: let $\mathfrak A_M(\mathcal O)$ denote the corresponding Minkowski local algebra and let
324: $\mathcal H_{\mathrm{OS}}$ be the reconstructed Hilbert space. Define the physical admissible
325: Hilbert space by
326: \[
327: \mathcal H_{\mathrm{adm}}:=\operatorname{Ran}(\Padm)\subset \mathcal H_{\mathrm{OS}}.
328: \]
329: Define the physical admissible local net by
330: \[
331: \mathfrak A_{\mathrm{adm}}(\mathcal O)
332: :=
333: \left\{
334: A|_{\mathcal H_{\mathrm{adm}}}\;:\;
335: A\in\mathfrak A_M(\mathcal O),\;
336: A\mathcal H_{\mathrm{adm}}\subset \mathcal H_{\mathrm{adm}},\;
337: A^\ast\mathcal H_{\mathrm{adm}}\subset \mathcal H_{\mathrm{adm}}
338: \right\}.
339: \]
340: Thus $\Padm$ acts as the selector of the physical state space, while the local net is defined by
341: restriction to the invariant admissible subspace rather than by compression with a global
342: projector.
343: \end{definition}
344: 
345: \begin{remark}[Bernstein realizations as analytic choices]
346: \label{ass:bernstein-positivity}
347: Whenever a Bernstein representation of a spectral test profile is used, it is treated only as an
348: analytic realization of a transfer channel already fixed by the closed datum and the canonical
349: projector. Positivity or reflection stability therefore does not enter the main text as a
350: primitive source of admissibility.
351: \end{remark}
352: 
353: \begin{theorem}[Primitive self-adjoint realization without extra analytic assumption]
354: \label{thm:well-posed-primitive-dynamics}
355: \label{thm:primitive-selfadjoint-realization}
356: Let $M_\Lambda$ be a finite cutoff of the primitive geometric anchor, so that $M_\Lambda$ is
357: compact with boundary. Let $D_{\mathrm{geo}}$ be the formally self-adjoint Dirac-type anchor and
358: let $A_\partial$ be an adapted boundary operator. Choose a self-adjoint $D_{\mathrm{geo}}$-elliptic
359: boundary condition $B_{\mathrm{sa}}$ of modified APS type:
360: \[
361: B_{\mathrm{sa}}=
362: \begin{cases}
363: H^{1/2}_{(-\infty,0)}(A_\partial), & \ker A_\partial=0,\\[2mm]
364: H^{1/2}_{(-\infty,0)}(A_\partial)\oplus L, & \ker A_\partial\neq0,
365: \end{cases}
366: \]
367: where $L\subset\ker A_\partial$ is chosen as in the normal form for self-adjoint $D$-elliptic
368: boundary conditions. Then the closed realization $D_{\mathrm{geo},B_{\mathrm{sa}}}$ is self-adjoint
369: Fredholm with discrete spectrum. If $D_{\mathrm{rel}}$ is a symmetric differential perturbation of
370: order at most one with bounded coefficients on $M_\Lambda$, then $D_{\mathrm{rel}}$ is
371: infinitesimally $D_{\mathrm{geo},B_{\mathrm{sa}}}$-bounded and therefore
372: \[
373: D_{\mathrm{geo},B_{\mathrm{sa}}}+D_{\mathrm{rel}}
374: \]
375: is self-adjoint on the same domain. In particular the finite-cutoff relative spectral seed is well
376: defined without an additional analytic existence hypothesis.
377: \end{theorem}
```

## experiments/theory-contracts/tfpt-unified-source-derivation-20261029/DERIVATION.txt

Original SHA256 244e67a13d177ee04d4a0be211d0983d0efe45e0a4263186fe15da62eaf538fd; Zeilen 1 bis 270.

```text
1: ONE DERIVATION PATH AND A SUFFICIENT CURRENT SOURCE RECOGNITION THEOREM
2: 29 October 2026
3: ====================================================================
4: 
5: Outcome and ownership
6: ---------------------
7: The original-source bridge is NOT proved here. This document combines the
8: already established constructions into one directed argument, identifies its
9: actual source obligation, and proves a sufficient reduction of the infinitely
10: many neutral current word comparisons to structural operator hypotheses.
11: The representation theorem is standard Heisenberg theory, applied here to the
12: ACTUAL folded eight-current normalization and original source time. It is not
13: a newly discovered general theorem or a newly constructed physical model.
14: 
15: This is an experiment/theory contract. Papers, verification scripts, ledger,
16: website and their proof statuses remain untouched. Finite exact controls
17: supplement the analytic proof. They do not prove a local net or all-mode result.
18: 
19: 1. One directed chain, with all input boundaries retained
20: ---------------------------------------------------------
21: INPUT: P1 declares an oriented reflection-positive seam kernel, unit winding
22: and c3=1/(8 pi). P2 declares the five-slot physical readout interface. The
23: original distinction between interface axiom and conditional algebraic
24: consequences is essential [S1]. Neither is just an isolated numerical value.
25: 
26: DISCRETE BRANCH: In the declared carrier/lattice/glue class, D5+A3 with its
27: marked Z4 glue constructs E8. The complete finite E6/E7 incidence geometry,
28: native clock actions, lattice lifts, code and field representation results
29: are reusable consequences under their recorded conjunctive hypotheses.
30: The marked C4 local E8 extension result is a classification INSIDE its stated
31: unitary conformal class. It is not a general inverse from finite invariants
32: to the physical microscopic source. Different clock markings remain distinct.
33: 
34: SOURCE BRANCH, CURRENTLY GIVEN REPRESENTATIVE: The original quarter CAR source
35: has the unitary fold eta_r(x)=psi((x+2 pi r)/8)/sqrt(8), its actual correlated
36: arc kernel, eigenchannels chi=U_alpha* eta, and eight currents j_a. The fixed
37: reference gives delta_a=(a+alpha)/8-1/2. No independent arc seas are added.
38: The old original matrices give A=U_+^T O^T M with AA*=I4, AA^T=0. Hence [S2]
39: 
40:  W8(z)=:I8(A(j(z)+delta/z))/(96 sqrt(140)): .
41: 
42: Here W8 is shorthand for exactly the native field F8^(d) in [S2]. It is
43: not automatically the separately studied E8-invariant primary completion.
44: 
45: This is already an actual even, source-neutral CAR composite. It requires
46: neither the complete charged E8 extension nor a new chosen state. Preserve
47: the old point splitting, derivative counterterms, adjoint and i0 prescription.
48: Its localization is the eight actual preimage arcs, not a single original
49: c=1 point. The two meanings of locality cannot be identified by dimension.
50: 
51: GIVEN VACUUM/MOBIUS BRANCH: In the larger original c=1 neutral current vacuum,
52: the compensated stress gives L0=H_alpha and the actual positive parabolic
53: generators P_k with H_alpha=(P0+P2)/2=(P1+P3)/2. Local algebras transport with
54: the cuts. This is the proved vacuum standard pair, not the elliptic Gibbs
55: state and not automatically the physical P1 time/reflection [S3].
56: 
57: GIVEN ELLIPTIC/TWO-FACE BRANCH: The existing free annulus construction has
58: its full graph projector and the given normal thermal source. The right
59: representation and ordered heat products yield the joint reflected HS Gram.
60: The physical P1 left face is not identified merely by naming a GNS partner.
61: The positive full-CAR-projector rigidity theorem is an alternative sufficient
62: test if that actual full covariance and CAR image are demonstrated [S4,S5].
63: 
64: THE REQUIRED JOIN: Exhibit in the actual original quantum source the relevant
65: local current/composite image, common state and time, with original
66: marks/references/domains. Actual reflection and the joint two-face
67: representation are additionally required for the claimed reflected two-face
68: or OS comparison; do not require a second face for an isolated W8 response.
69: For a W8-only claim a full CAR/E8 embedding is stronger than necessary. A
70: complete operational Seed already supplies its state; no second arbitrarily
71: chosen Berezin measure is universally required. For a geometric boundary
72: tuple alone, the needed quantum insertion/representation map is not supplied
73: by calling a Calderon polarization a full generating functional [S6].
74: 
75: AFTER A VALID JOIN: The existing full-moment OS transport gives an isometry
76: onto the corresponding cyclic image and intertwines the genuine transfer,
77: provided its contraction/domain hypotheses hold. It uses derivatives of
78: Z/Z[0], not derivatives of log Z as if they were full moments [S7].
79: Physical spacetime, interacting continuum, electromagnetic readout, mirror
80: sector and gravity remain their separate original T1--T8 obligations. Closing
81: this one source join must not silently mark the entire theory complete.
82: 
83: 2. Sufficient recognition theorem for the actual folded neutral currents
84: ------------------------------------------------------------------------
85: Let H be the ACTUAL self-adjoint nonnegative source generator, Omega a unit
86: vector with H Omega=0. Suppose an invariant dense domain contains Omega and
87: every finite word of operators j_(a,n), a=0,...,7, n integer, together with all
88: H actions needed below. On that domain assume
89: 
90:  j_(a,n)*=j_(a,-n),
91:  [j_(a,m),j_(b,n)]=m delta_ab delta_(m+n,0) I,
92:  [H,j_(a,n)]=-8n j_(a,n),       Q_a Omega=j_(a,0) Omega=0.        (R)
93: 
94: The actual positive-time or unitary covariance and these domain relations
95: must justify the displayed commutators. A formal equality between unrelated
96: one-particle B and many-body H is not (R).
97: 
98: Claim: On the closed cyclic eight-current space, these hypotheses uniquely
99: fix all finite ordered current moments and the original source evolution.
100: No independent Fock, Gaussian or full-CAR premise is needed for this claim.
101: 
102: Proof. For n>0, H j_(a,n) Omega=-8n j_(a,n) Omega. Nonnegative spectrum
103: forces j_(a,n) Omega=0. Adjunction also gives <Omega,j_(a,-n)X Omega>=0.
104: For a word M((a,n),w)=<Omega,j_(a,n)w Omega>, commute a positive n through
105: the remaining word to the right. The last term vanishes; each commutator is
106: central. Therefore
107: 
108:  M(empty)=1,
109:  M((a,n),w)=0                                      if n<0,
110:  M((a,n),(a1,n1),...,(ak,nk))
111:    =sum_(r=1)^k n delta_(a,ar) delta_(n,-nr) M(w without r)   if n>0. (1)
112: 
113: Zero modes vanish on the whole cyclic space since they commute with all
114: currents. Equation (1) fixes EVERY word by induction, including all mixed
115: channel moments. It is a derived Wick recursion, not a Gaussian input.
116: 
117: Write v_k=product_(a,n>0) j_(a,-n)^k_(a,n) Omega for a finite multiindex.
118: Repeated CCR give the exact Gram matrix
119: 
120:  <v_k,v_l>=delta_(k,l) product_(a,n>0) n^k_(a,n) k_(a,n)! .     (2)
121: 
122: Thus mapping the standard oscillator word v_k to this actual original word
123: is well defined, isometric and extends to a unitary U ON THIS CYCLIC SPACE.
124: Every v_k has energy 8 sum n k_(a,n). These eigenvectors span the cyclic
125: space, which reduces H. The finite word span is a core for the restriction;
126: the unitary transports the self-adjoint energy closure and its full groups.
127: On this core H=8 sum_(a,n>0) j_(a,-n) j_(a,n). This proves the claim.
128: 
129: This is a sufficient certificate for this particular free current subtheory.
130: It is not a necessary condition on every possible physical P1 source. A
131: coupled original sector must not be forced to obey (R) to recover a desired
132: answer. The same test can reject a candidate without excluding all TFPT.
133: 
134: 3. Exact clock consequence: keep the two cyclic spaces distinct
135: ---------------------------------------------------------------
136: The original source quarter on total Q=0 is R=exp(-i pi H_alpha/2) [S3].
137: For the present eight-current cycle H=8N. Consequently
138: 
139:                   R|_(eight-current cycle)=I .                (3)
140: 
141: This is consistent with R j_(a,n) R*=i^(8n)j_(a,n)=j_(a,n).
142: The nontrivial four parabolic generators in [S3] belong to the larger c=1
143: current cycle with all integer Fourier energies. It would be an error to
144: claim a nontrivial quarter orbit on W8 from the eight-current certificate.
145: Equation (3) neither identifies the native compiler J nor removes the
146: charged holonomy/carry or the larger source clock information.
147: 
148: 4. Locality and the two faces are actual hypotheses, not automatic outputs
149: -------------------------------------------------------------------------
150: Finite real mode sums have their standard self-adjoint closures through U.
151: For smooth fields and actual local von Neumann algebras require the original
152: smearing to agree with their convergent Fourier sums, controlled by energy
153: bounds or another proved domain/strong-resolvent argument. Then U transports
154: the Weyl algebras generated by those very smeared currents.
155: 
156: The support map must still carry quotient intervals to the real eight arcs.
157: An abstract unitary of global current modules does not prove that support
158: statement or turn multiarc charged transfers into additive single-arc fields.
159: 
160: For two reflected words, assume the ORIGINAL Theta maps the relevant words
161: to the corresponding known source words, with actual product/order,
162: adjoint, time, charge/cocycle and phase conventions. The moment identity
163: then gives equality of all reflected word kernels at once. If Theta maps
164: to a second, as yet unidentified, algebra, this hypothesis has NOT been
165: checked: separate one-face Ward identities do not determine cross moments.
166: The common representation/reflection must be constructed or compared.
167: 
168: After the fixed A, delta and existing controlled point-splitting prescription
169: are transported, the same argument transports W8 and its ordered responses.
170: A new point-field coincidence limit needs its own control. Neither the
171: eight-current cycle nor W8 is the entire original neutral c=1 local net.
172: 
173: 5. Thermal variant and a precise remaining null-mode test
174: ---------------------------------------------------------
175: For an actual beta-KMS source for this rotation, with a legitimate analytic
176: extension to the unbounded words under consideration, the KMS relation is
177: 
178:  omega(W j_(a,n))=exp(-8 beta n) omega(j_(a,n) W).
179: 
180: Combining this with the CCR gives, for nonzero n,
181: 
182:  omega(j_(a,n)W)
183:    =sum_r [n delta_(a,ar) delta_(n,-nr)/(1-exp(-8 beta n))]
184:               omega(W without r).                            (4)
185: 
186: It holds also for n<0 and yields the positive Bose occupation. Iteration
187: fixes every oscillator moment, including moments with retained central
188: zero-mode words as coefficients. KMS does NOT choose the joint law of Q_a,
189: the original background delta, or the common second face.
190: 
191: Indeed, on the neutral current algebra rotation acts trivially on Q. A
192: thermal oscillator state tensored with ANY positive central Q law is KMS
193: for that algebraic dynamics. The laws delta_0 and (delta_1+delta_-1)/2
194: have the same mean Q=0 but different <Q^2>. This is a source-algebra
195: countercontrol, not two complete admissible P1 worlds. It prevents the
196: incorrect replacement of the actual thermal zero-mode law by a vacuum.
197: At the source beta=4 pi one must keep that exact beta and its charge law;
198: the diagnostic q=1/3 in the checker is only an exact arithmetic control.
199: 
200: 6. The old claimed shortcut and its smallest valid repair
201: ---------------------------------------------------------
202: The following are EXISTING Atlas results, not new discoveries:
203:  finding:minimal-defect-uniqueness-not-proved;
204:  finding:original-minimality-does-not-reconstruct-operational-source;
205:  finding:paper-seed-source-needs-local-image-not-global-equivalence.
206: 
207: The original d_seed=d composed C_seed yields minimization over im(C_seed),
208: not automatically all SBord. The precise sufficient repair of its boundary
209: corollary is (i) a genuine seed hitting a global minimal defect value and
210: (ii) uniqueness of the reachable boundary stratum at that value. Even this
211: would fix a boundary image, not by itself its complete state/reflection/time
212: fiber. Full global categorical surjectivity is stronger than necessary.
213: 
214: A later full/faithful/essentially-surjective statement in the original QFT
215: source 006:275--311 is explicitly disabled by the TeX conditional
216: \\iffalse ... \\fi. The active successor 313--343 states only
217: that a different internal reduction lands in one rigid target orbit. It is
218: not an active theorem supplying the missing physical source map [S8].
219: No universal impossibility or universal loss of information follows.
220: 
221: 7. What changes the next actual calculation
222: -------------------------------------------
223: Reuse the existing discrete E8/clock/glue results, the actual W8 construction,
224: the two-face HS calculation and the vacuum Moebius theorem. Do not rescan
225: their already closed candidate spaces. Do not rerun the minimality audit
226: as a new discovery. Do not compare infinitely many arbitrary neutral words
227: if the structural recognition certificate can be proved in the source.
228: 
229: Find the actual P1 insertions and their represented operators. For a candidate
230: full current image the first decisive relation is the local continuous Weyl
231: cocycle or its justified current CCR, followed by the SAME original time Ward
232: and actual state type. Then original eight-arc support, reflection and common
233: face representation must pass, with (1) or (4) providing the word values.
234: An isolated W8 image may use a smaller direct composite map; it need not
235: contain the full current or charged field algebras.
236: 
237: No candidate original current image has been constructed in this contract.
238: Its absence here is an unresolved derivation, not an impossibility theorem.
239: The complete fundamental TFPT solution therefore remains unproved.
240: 
241: Sources
242: --------
243: [S1] documents/tfpt_1_architecture_e8/sections/001-source.tex:67--98.
244: [S2] experiments/theory-contracts/native-octic-seam-origin-20261025/
245:      CAR-OCTIC-DICTIONARY.txt:1--109.
246: [S3] experiments/theory-contracts/elliptic-moebius-source-bridge-20261026/
247:      neutral_moebius_source_20261029/PROOF.txt:1--193;
248:      experiments/theory-contracts/joint-native-algebra-selection-20261016/
249:      ORIGINAL-ORDERED-CURRENT-KERNEL-AND-SEAM-GRADING.txt:166--180.
250: [S4] experiments/theory-contracts/elliptic-moebius-source-bridge-20261026/
251:      two_face_source_20261029/PROOF.txt:1--185.
252: [S5] experiments/theory-contracts/native-arc-charge-source-interface-20261026/
253:      PROJECTOR-STATE-RIGIDITY.txt:1--173.
254: [S6] documents/archive--tfpt-45--source_extracts--01_boundary_kernel_source/
255:      sections/002-section-intrinsic-closed-branch-and-canonical-rigid-obje.tex:
256:      103--144,219--306; 001-section-primitive-core-and-carrier-interface-handoff.tex:
257:      65--110,302--343. Neither P_C nor 2P_C-I is thereby an original CAR state.
258: [S7] experiments/theory-contracts/primitive-seam-operator-reconstruction-20261025/
259:      OS-SOURCE-REPAIR.txt:181--260.
260: [S8] documents/archive--tfpt-45--source_extracts--04_qft_source/sections/
261:      006-section-internal-reduction-theorem-and-renormalized-obse.tex:275--350.
262: [P1] Adamo, Giorgetti, Tanimoto, Wightman Fields for Two-Dimensional Conformal
263:      Field Theories with Pointed Representation Category (2023), section6.1.
264:      https://doi.org/10.1007/s00220-023-04835-1
265:      Standard current-module inner product, closures and actual smeared net.
266: [P2] Carpi, On the Representation Theory of Virasoro Nets (2003), section4,
267:      equations44--47. https://arxiv.org/abs/math/0306425
268:      Primary reference for the irreducible lowest-weight oscillator module.
269: The elementary proofs of (1),(2),(4) are supplied above; no physical TFPT
270: claim is inferred from the cited general representation theory.
```

## experiments/theory-contracts/tfpt-unified-source-derivation-20261029/original_insertions/PROOF.txt

Original SHA256 637007e39986ac8f2ec07a6c2ce96f0d5686171583b226699ea9dfe9ca3bb4fc; Zeilen 1 bis 255.

```text
1: ORIGINAL INSERTIONS, MIXED CURRENTS AND THE PRODUCT TIME TEST
2: 29 October 2026. Continuation of tfpt-unified-source-derivation-20261029.
3: Verdict: ESTABLISHED_SCOPED; ORIGINAL_PHYSICAL_P1_IMAGE_UNPROVED.
4: 
5: 1. Target, reused sources and precise changed premise
6: 
7: The target is the actual original source image, including its time and state.
8: DERIVATION.txt in the parent contract already proves a sufficient all-word
9: recognition theorem. We do not repeat it or assume its hypotheses in P1.
10: The old full-vector cocycle exclusion is retained in its actual scope:
11: collar-current-source-bridge-20261021/DIRAC-LIFT-ADMISSIBILITY.md, sections1-3.
12: It explicitly leaves mixed vector/axial currents outside that exclusion.
13: Here we use exactly that different generator inside the already supplied
14: full complex CAR source, then test the existing finite product coefficient.
15: No new independent chiral determinant, free state or fitted coupling is added.
16: This conditional CAR source itself was not derived from thin P1.
17: 
18: Original finite operators are v252_full_finite_triple.py, lines86-168;
19: v254_inner_fluctuations.py, lines47-60 and85-99. The insertion audit
20: seam-collar-multifield-20261016/P1-INSERTION-TANGENT.txt already separates
21: primitive action variation, finite one-forms and the actual source jet.
22: The explicit qM witness and full left/right statement are already in
23: seam-joint-source-origin-audit-20261016/HIGGS_VARIATION_PROOF.txt:135-182,
24: finding:finite-sm-higgs-variation-retains-seed. We reuse that result;
25: it is not counted as a newly derived P1 source.
26: We also retain the previously proved positive-compression carrier exclusion;
27: it is neither a new result nor a no-go for the entire original construction.
28: 
29: 2. Follow an actual finite one-form before naming it a current
30: 
31: On a particle doublet, put a_F=pi(0,q,0), b_F=pi(1,0,0).
32: In left/right internal order the actual representation and Dirac block give
33:   a_F=[[q,0],[0,0]], b_F=[[0,0],[0,I]],
34:   D_F=[[0,M],[M*,0]], M=diag(Y_up,Y_down).
35: Consequently a_F b_F=0 and
36:   a_F[D_F,b_F]=[[0,qM],[0,0]].
37: Its selfadjoint completion is V_q=[[0,qM],[M*q*,0]].
38: The analogous lepton block uses Y_nu,Y_e. The actual full representation
39: also has antiparticles and Majorana terms; the checker uses its full96 block.
40: Its selected one-form has only the particle upper-right part, as above.
41: The Yukawa and Majorana matrices remain supplied inputs of that constructor.
42: 
43: For D=D_M tensorI+gamma5 tensorD_F, a=f tensora_F, b=g tensorb_F,
44:   a[D,b]=f[D_M,g] tensora_F b_F
45:           +fg gamma5 tensora_F[D_F,b_F].
46: For this particular witness the first term is ZERO. Therefore this insertion
47: is an actual internal Higgs/Yukawa direction, not already a conserved current.
48: Central coordinate one-forms instead recover Clifford multiplication c(dg).
49: Neither one-particle insertion is automatically a many-body P1 field image.
50: 
51: 3. An explicit right current in the already given complete CAR source
52: 
53: Retain the original two-component product collar, its two boundary faces,
54: and alpha=1/4 or3/4. These components are not two particles or two faces.
55:   A=-i partial_theta+alpha, Gamma=diag(1,-1),
56:   Jn=[[0,-1],[1,0]], S=Jn Gamma=[[0,1],[1,0]],
57:   B0=Gamma A, D0=Jn(partial_r+B0).
58: The old pure graph on BOTH faces is
59:   G(B)=[[a,c],[c,1-a]],
60:   a=(1+exp(-2ell B))^-1, c=(2cosh(ell B))^-1.
61: On its second face n(B0)=diag(n(A),1-n(A)),
62:   n(A)=(1+exp(2ell A))^-1.
63: This is a thermal face of the existing pure joint state, not a newly selected
64: Hardy vacuum. Normal ordering and charged CAR remain the old source premise.
65: 
66: Use smooth real functions on that SAME face and even quadratic currents
67:   J_V(f)=:Psi* fI Psi:, J_A(f)=:Psi* fGamma Psi:,
68:   J_R(f)=(J_V(f)+J_A(f))/2=:Psi* fP_R Psi:,
69:   J_L(f)=(J_V(f)-J_A(f))/2, P_R=(I+Gamma)/2.
70: These are existing smeared quadratic generators, under the old implementability
71: conditions. Restricting to their algebra does not replace the full determinant.
72: The old infinite telescoping identity gives opposite component cocycles c,-c.
73: For component coefficients x=(x_R,x_L),y=(y_R,y_L), bilinearity gives
74:   c(x,y)=(x_R y_R-x_L y_L)c.
75: In particular c_VV=c_AA=0, c_VA=c_AV=2c, c_RR=c.
76: For the original f=sin(4theta),g=1-cos(4theta), c=-2i;
77: the mixed value is -4i and the right value -2i. Cross entries use different
78: profiles; there is no conflict with antisymmetry under exchanging BOTH inputs.
79: The normal-pairing exclusion does not apply to Gamma: [Gamma,Jn]!=0.
80: This is standard vector/axial current algebra applied to the retained source,
81: not a new general anomaly theorem or a four-dimensional particle identification.
82: 
83: On trigonometric H1 vectors let X_n e_k=e_(k-n). Then [A,X_n]=-n X_n and
84:   [B0,IX_n]=-n Gamma X_n,
85:   [B0,Gamma X_n]=-n IX_n,
86:   [B0,P_R X_n]=-n P_R X_n.
87: These are exact one-particle identities and determine the corresponding CAR
88: automorphism action. With the original eightfold modes replace n by8n.
89: Calling this actual P1 OS time would still require the original time dictionary.
90: Its thermal face does NOT imply a positive vacuum generator H Omega=0.
91: The parent recognition theorem must use the actual KMS alternative here,
92: retaining the joint zero-mode law, delta and original support dictionary.
93: 
94: 4. Keep the existing finite product term in that time test
95: 
96: In this explicit two-dimensional collar take a constant finite selfadjoint Phi.
97: The even product expression and its actual tangential factor are
98:   D_Phi=D0+Gamma tensorPhi=Jn(partial_r+B_Phi),
99:   B_Phi=Gamma A-S tensorPhi.
100: This is a bounded perturbation of B0 on its original H1 domain. A acts
101: trivially on the finite space; no varying normal profile is presumed.
102:   [S,P_R]=Jn,
103:   [B_Phi,P_R X_n]+nP_R X_n=-Jn tensorPhi X_n.
104: Thus for nonzero Phi the bare geometrically right current algebra exists
105: at equal time but is not invariant under this same source time evolution.
106: This already follows from the bounded n=0 projection commutator; no
107: differentiation of a putative massive Fock Hamiltonian on a massless vacuum
108: or comparison of a finite cutoff CCR is being used.
109: 
110: For an internal orthoprojection E, the pure-right channel obeys
111:   [B_Phi,P_R tensorE]=[[0,E Phi],[-Phi E,0]].
112: It reduces B_Phi iff Phi E=0. Selfadjointness gives E Phi=0 as well.
113: This proves a necessary and sufficient kernel criterion in THIS product class.
114: It does not show whether P1 selects any such channel.
115: 
116: For a general even-dimensional product the correctly typed formula is
117:   D_M=Jn(partial_r+B_t),
118:   B_prod=B_t tensorI-Jn gamma5 tensorD_F.
119: Here {Jn,gamma5}=0, [B_t,gamma5]=0, {B_t,Jn}=0.
120: Jn gamma5 is a selfadjoint involution anticommuting with B_t and gamma5.
121: The displayed two-component Gamma is the chirality of the chosen old collar.
122: We do not identify that fiber with a complete four-dimensional spinor module.
123: 
124: 5. Classification of ALL constant time-reducing projections in this class
125: 
126: Let K be any finite complex space and Phi=Phi*. A constant orthoprojection E
127: on C2 tensorK reduces B_Phi(p)=p Gamma-S tensorPhi for all Fourier momenta p
128: iff it commutes separately with Gamma and S tensorPhi. Any two distinct
129: momenta suffice for this coefficient comparison. Thus exactly
130:   E=diag(E_R,E_L), E_R Phi=Phi E_L, E_L Phi=Phi E_R.
131: The diagonal entries are orthoprojections. The equations imply commutation
132: with Phi^2 and so a splitting by its squared-mass eigenspaces.
133: For K_mu=ker(Phi^2-mu^2), mu>0, set U_mu=Phi/mu on K_mu.
134: U_mu is a selfadjoint unitary. Every solution there is
135:   E_R=Q_mu, E_L=U_mu Q_mu U_mu
136: with an arbitrary orthoprojection Q_mu. On K0=kerPhi the two projections
137: E_R^0,E_L^0 are independent. Conversely every such choice satisfies all the
138: equations. This proves completeness, including repeated and signed masses.
139: The linear commutant has complex dimension sum_(mu>0)dim(K_mu)^2+2dim(K0)^2.
140: In particular the massive right and left ranks are equal.
141: 
142: The corresponding scalar current cocycle is zero on the massive part.
143: Proof uses the existing full-graph Lagrange lemma rather than a regulator.
144: On K0-perp put F=signPhi and N'=Jn tensorF. Then N' is unitary,
145:   N' B_Phi N'*=-B_Phi, [E,N']=0.
146: For the full two-face graph N_face=diag(-N',N') satisfies
147:   N_face G(B_Phi) N_face*=1-G(B_Phi).
148: A one-face generator fE commutes with N_face. If the off-diagonal blocks
149: are Hilbert Schmidt, the old trace-class cocycle lemma gives c(fE,gE)=0.
150: This is its usual circle smoothness class, not an unrestricted higher
151: dimensional trace formula. N' is an algebraic pairing, not an OS reflection.
152: On K0 the original independent massless right and left components remain.
153: Consequently the full channel's central coefficient, in units of c, is
154:   kappa(E)=rank(E_R^0)-rank(E_L^0).
155: An invertible Phi therefore leaves no nonzero scalar chiral level in ANY
156: constant reducing channel in this class. Momentum-dependent nonlocal
157: projections, variable profiles and actual normal index modes are not classified.
158: 
159: 6. Retain the product grading and the true reflection question
160: 
161: For the existing finite triple {Phi,gamma_F}=0. Therefore
162:   [B_Phi,Gamma tensorgamma_F]=0.
163: The positive TOTAL graded sector is a genuine reducing channel. It contains
164: R tensorker(gamma_F-I) AND L tensorker(gamma_F+I).
165: Its central coefficient is tr_(kerPhi)(gamma_F); the massive part is balanced.
166: The complete actual v252 complex96 space has48 positive and48 negative
167: internal grades. Since Phi pairs the opposite internal grades on every
168: nonzero squared-mass eigenspace, tr_(kerPhi)(gamma_F)=tr_K(gamma_F)=0
169: also for singular Phi. Hence the full TOTAL graded channel has zero scalar
170: level for every such finite odd coefficient. An individually selected kernel
171: channel can still have a nonzero level, as section5 proves. This equality
172: is not a physical particle count or a Pfaffian statement.
173: Its invertible constructor control below has zero kernel;
174: it demonstrates the cancellation, not a derivation of physical Yukawa ranks.
175: For arbitrary invertible input Y_nu,Y_e,Y_u,Y_d, the actual full_D is invertible
176: even with Majorana MR: left neutrino equations first force right neutrinos
177: to zero, also in the antiparticle block; right equations then force the left
178: ones to zero. Charged blocks are directly invertible. This does not fix inputs.
179: 
180: There is also an explicit candidate for the geometric product reflection.
181: On the old collar r->-r with fiber S preserves D0. For constant Gamma Phi
182: the fiber S alone flips that term. If {gamma_F,Phi}=0, the combined fiber
183:   R_prod=S tensorgamma_F
184: preserves D_Phi together with r reversal. This follows by conjugating both
185: normal and tangential symbols and the potential. It is not proof of its
186: domain, reference, admissibility or OS positivity. In the original relative
187: split an R-odd term can itself be intended, so failure of the bare S symmetry
188: is not by itself inadmissibility of that term.
189: 
190: 7. Reuse the EXISTING normal-index result without a new operator choice
191: 
192: The normal index line was already computed in original-admissible-source-
193: closure-20261025/NORMAL-INDEX-TRANSPORT.txt, sections1-3. Its source-product
194: identification was explicitly conditional. It is not missing work to repeat:
195:   B_normal=B_a tensor gamma_N+I tensor D_N,
196:   ker D_N^+=C, ker D_N^-=0 for the stated spin twist by L2=O(1),
197:   B_normal V_chi=V_chi B_a on the whole domain.
198: The old horizontal holonomy test and moving-kernel Kato criterion remain
199: necessary in a genuine family. The present constant finite Phi test does not
200: replace the normal elliptic D_N by the supplied finite Yukawa matrix D_F.
201: 
202: On the ALREADY reducing finite normal kernel K0, the old scalar-current
203: calculation and direct sums immediately give
204:   c_kernel=(dim ker D_N^+ - dim ker D_N^-)c=(index D_N^+)c.
205: This only uses the finite kernel and its existing product embedding. It does
206: not apply an unrenormalized circle trace formula to the full higher-dimensional
207: bulk. The determinant-line spin case has one positive mode and no negative
208: one; it transports both level1 and the same source-time Ward on that image.
209: This closes the conditional current-algebra part of that OLD product result.
210: 
211: For the full E2 spin twist, the old example E2=O(k) direct_sum O(1-k)
212: has r_plus=k,r_minus=k-1. Its NET scalar cocycle is still level1. Thus kernel
213: rank1 is unnecessary if the requested observable is ONLY this net phase.
214: It remains necessary to check the stronger one-current/time identification:
215:   [B_normal,J_kernel,n]=-n(J_plus,n-J_minus,n),
216: whereas J_kernel,n=J_plus,n+J_minus,n. If r_minus>0 this is not the old single
217: right-current Ward. In particular net index1 alone does not provide the
218: all-word/time recognition theorem or a canonical actual rank1 subchannel.
219: No arbitrary positive mode or mass profile is chosen to remove the extra pairs.
220: 
221: The remaining original question is the already named product-source map and
222: horizontal transport, now with explicit mixed current operators to test.
223: Neither a different Spin-c operator (index2) nor the bosonic Callias witness
224: can be substituted merely because an index is small or equals1.
225: 
226: 8. What this actually resolves and what remains the single source step
227: 
228: Resolved in the given full CAR collar: the mixed vector/axial route provides
229: an explicit chiral current, and its original geometric source time is linear.
230: No additional chirally quantized measure is required for this restriction.
231: Resolved for the constant finite product coefficient: the same bare current
232: fails time invariance; ALL constant reducing channels and their net scalar
233: levels are classified. Correct total grading and an internal reflection lift
234: survive; we do not declare the product construction inconsistent.
235: 
236: The next original-source question remains the missing actual embedding in
237: the old normal result: does its coupled normal/admissibility operator really
238: have that product/family action and horizontal transport, with the required
239: current image, seam/quarter action and joint reflection? Its actual state and
240: OS time must be carried through that embedding. A supplied invertible finite
241: Yukawa block does not answer this normal index problem.
242: No arbitrary zero Yukawa, normal kink or chirality filter is inserted here.
243: The existing finite Higgs insertion is not itself that source derivation.
244: Full physical P1 pushforward, electromagnetic readout and T1-T8 remain open.
245: 
246: 9. Verification and source protection
247: 
248: check_original_insertions.py imports the actual v252 constructor and rep,
249: with exact integer controls, and converts entries to exact Gaussian integers
250: before testing. It checks all four quaternion witnesses, source Clifford/time
251: and grading relations, all linear commutants for four decisive signed/kernel
252: cases, non-diagonal reducing and unpaired kernel projections, and VA phases.
253: All finite checks use explicit exceptions, so python -OO retains them.
254: Finite controls support but do not replace the all-parameter proof above.
255: No original paper, verification script, ledger, manifest or website is edited.
```

## experiments/theory-contracts/seam-collar-multifield-20261016/P1-INSERTION-TANGENT.txt

Original SHA256 b49aa4ec77bc22029545c4f8f2584e80e63fd8bb6b8a0ce8536baf4137d3ea55; Zeilen 1 bis 135.

```text
1: P1 INSERTIONS: SOURCE JET, MODULAR READER AND ACTUAL E8 SECTOR ACTION
2: 16 October 2026; continuation of UR.SEAM.COLLAR_MULTIFIELD.01
3: Verdict: SOURCE_JET_NOT_DERIVED_CONDITIONAL_ACTION_EXPLICIT
4: 
5: 1. Requested conclusion and source boundary
6: 
7: Derive the actual Phi-dependent insertions from the original P1 kernel, their
8: fermion-sector action, and the map to existing fields without choosing a coupling.
9: This conclusion is NOT established. The calculation below supplies an exact
10: necessary interface and the actual current-sector action. It does not replace
11: the missing original source family with a constructed Higgs coupling.
12: 
13: Read original sources, not just their graph labels:
14: S1 = _archive/tfpt-45/source_extracts/01_boundary_kernel_source.tex:
15:   69-82: (A_+,H_+,D_+,J,Gamma,B_Sigma) is a supplied boundary datum;
16:   122-130: relative/reference split from D and the geometric reflection;
17:   192-268: primitive admissibility uses the positive Calderon sector;
18:   302-316: S_prim[chi] is a relative spectral action with declared f;
19:            carrier-compatible bosonic fluctuations enter later;
20:   319-343: physical local insertions are introduced through a source algebra.
21: S2 = _archive/tfpt-45/source_extracts/02_carrier_source.tex:
22:   1795-1814: inner fluctuations on the already anchored branch;
23:   1990-2023: B_Ea=sigma.nabla^(a)+Phi_a is on already labeled E2/E3 bundles;
24:   2104-2117: standard Yukawa terms follow the claimed Higgs selection.
25: S4 = _archive/tfpt-45/source_extracts/04_qft_source.tex:
26:   461-472: relative Z has a fixed reference denominator;
27:   2160-2184,2272-2302: effective action/vertices are written through S_adm[phi]
28:   and its derivatives, rather than defining its microscopic Phi insertion.
29: 
30: Naming Phi as Higgs (S1:9) is not a definition of a map Phi -> D_+[Phi].
31: Nor is its absent argument permission to set its derivative to zero. To
32: differentiate, an actual curve in source data must be supplied or derived.
33: 
34: 2. What can be differentiated before assuming a coupling
35: 
36: For a differentiable source curve with fixed reflection R, fixed f and chi,
37: V=dot D gives V_rel=(V-RVR)/2 and V_ref=(V+RVR)/2. In a finite regulator,
38:   dot S_prim = chi^-1 Tr[f'(D_rel/chi) V_rel]
39:              -chi^-1 Tr[f'(D_ref/chi) V_ref] + i*pi*dot Delta_eta/2.
40: This uses trace cyclicity, not commutativity of D and V. If the original
41: chi=lambda_1^+(|B|)^-1 varies, its derivative also contributes. If R varies,
42: dot(RDR)=dot R D R+R dot D R+R D dot R. These terms cannot be dropped while
43: claiming an unrestricted source derivation. Spectral crossings, eta jumps
44: and changing domains require separate treatment.
45: 
46: The unknown V is precisely the insertion to be derived. Substituting a desired
47: matrix into V would beg the question. The one-form mechanism likewise needs
48: the ACTUAL represented a,b in A_+: A=sum a[D,b]. Its usual real completion
49: requires order one; without it retain the generalized quadratic term, rather
50: than importing an SM calculation. Chamseddine/Connes/van Suijlekom,
51: arXiv:1304.7583, equations(2),(3) and section III.
52: 
53: 3. Follow the existing modular/covariance route without replacing it
54: 
55: verification/v258_dirac_covariance_induction.py:65-76 supplies the actual reader
56:   h(C)=log(I-C)-log C,       0<C<I,
57: and its inverse f_FD(H)=(I+exp H)^-1. This is the standard faithful quasi-free
58: one-particle dictionary (Peschel, cond-mat/0212631); it is not valid for an
59: arbitrary interacting current state from its two-point function alone.
60: Use the covariance convention C_ij=omega(c_j^* c_i) of this existing collar
61: construction; Peschel's opposite index convention has a transpose in eq.(12).
62: 
63: The script:85-128 constructs C from random Dirac/Yukawa matrices and a given
64: mass list before inversion. Line150 checks the seam identification with a
65: literal True. The inverse identity remains valid; those calculations do not
66: derive the physical embedding or its Phi variation. No verification script
67: or original ledger status is changed here.
68: 
69: For a differentiable embedded carrier use an isometry Q(Phi):H_F -> H_Sigma,
70: not a silent basis identification. Then
71:   C_F = Q* C_Sigma Q,
72:   dot C_F = Q* dot C_Sigma Q + dot Q* C_Sigma Q + Q* C_Sigma dot Q.
73: Even a fixed ambient covariance can have a changing compressed covariance
74: when Q moves. Source charge/field maps and their motion must be derived.
75: 
76: For finite faithful C with eigenvalues c_m, diagonalize C, not dot C. The exact
77: Frechet derivative is
78:   [dot h(C)]_mn = h^[1](c_m,c_n) [dot C]_mn,
79: where h^[1](x,y)=(h(x)-h(y))/(x-y) for x!=y and
80:   h^[1](x,x)=-1/[x(1-x)].
81: Proof: differentiate both matrix logarithms using
82:   D log(X)[E]=integral_0^infty (X+t)^-1 E (X+t)^-1 dt.
83: For the first logarithm delta X=-E; for the second it is E with a minus sign.
84: Every coefficient is strictly negative. Thus the derivative is an invertible
85: linear map on finite Hermitian matrices. This is not the commuting shortcut
86: -E/[C(I-C)] when E and C do not commute.
87: 
88: If the stated sector projectors commute with the background C, the same
89: spectral decomposition can be taken within their sectors. The Frechet map
90: restricts invertibly to every sector block. Consequently
91:   P_a dot h(C) P_b = 0  iff  P_a dot C P_b = 0.
92: It neither creates a missing sector block nor chooses one. Do not apply this
93: block claim to arbitrary projectors not commuting with C. Chirality-odd
94: projection, a varying chirality, a varying scale and moving readouts are extra
95: explicit operations; their source provenance must be retained. In particular
96: the result does not exclude preexisting background mixing or nonlinear effects.
97: An infinite-dimensional/unbounded extension needs its own domains and bounds.
98: 
99: 4. Resolve the projection-versus-occupation distinction on the retained source
100: 
101: The original Calderon Cauchy operator is a PROJECTION. h(P_C) is not a finite
102: faithful-covariance logarithm. For finite isometric Q,
103:   Q* P_C Q has eigenvalue1 iff Ran Q meets Ran P_C nontrivially,
104:   Q* P_C Q has eigenvalue0 iff Ran Q meets ker P_C nontrivially.
105: Proof: norm equalities for an orthogonal projection. In particular, restriction
106: to its own range is I, not a mixed occupation. Therefore one cannot identify
107: the same positive admissibility subspace with a faithful occupation simply by
108: using a compression symbol. This is a conditional consistency test, not a
109: claim that every compression of a projection is pure.
110: 
111: The previously constructed TWO-FACE collar supplies the correct mixed object.
112: For its given selfadjoint B and positive length ell, put R_c=exp(-ell B). Then
113:   A=(I+R_c^2)^-1,
114:   P_graph=[[A,A R_c],[R_c A,R_c^2 A]],
115:   n=I-A=(I+exp(2ell B))^-1.
116: The full P_graph is a projection; n is the mixed one-face occupation. Hence
117:   h(n)=2ell B,
118:   D h(n)[dot n]=2ell dot B+2 dot ell B.
119: The last identity holds also for a noncommuting bounded variation on a common
120: appropriate finite/regulated domain; it follows by differentiating the exact
121: functional inverse, without a freely chosen vertex. It recovers the insertion
122: already in B(Phi), and cannot supply a previously unspecified dot B.
123: 
124: Reuse the retained lowest charged particle/hole transfer pair R_c=diag(1/4,1/64).
125: The exact graph projection has A=diag(16/17,4096/4097),
126: n=diag(1/17,1/4097), h(n)=diag(log16,log4096).
127: At ell=8log2 this returns B=diag(1/4,3/4), with the already specified transfer
128: and quarter source in its POSITIVE particle/hole excitation chart. It is not
129: the signed raw one-particle B before the sea/particle-hole transformation.
130: Its own-range covariance is I, exactly as above.
131: This preserves the prior positive construction; it is not a new source choice.
132: Numerical eigenvalue clipping in v258 is a regulator, not a proof of h(I).
133: 
134: 5. Actual E8 insertion action: use the existing reader, no chosen Yukawa tensor
135: 
```

## experiments/theory-contracts/collar-current-source-bridge-20261021/DIRAC-LIFT-ADMISSIBILITY.md

Original SHA256 dc50b3805ba93a1a4e19890ea0accb04e66cebe192ce526e405cb362a6cdda6a; Zeilen 1 bis 248.

```text
1: # Full Dirac lift of the relative endpoint family
2: 
3: Research continuation of `UR.COLLAR.FACE_CURRENT.01`, 21 October 2026.
4: Verdict: **conditional structural obstruction to an automatic P1 identification**.
5: The scalar current result in PROOF.md is retained. It must not be promoted to
6: the current of the entire selfadjoint Dirac module without the following test.
7: No general mathematical novelty or completed TFPT solution is claimed.
8: 
9: ## 1. The original module, not an added mirror model
10: 
11: Use the already present product Dirac realization, from
12: `seam-full-collar-reconstruction-20261015/PROOF.txt:21-61`:
13: 
14: ```
15: A = -i partial_theta + alpha,  alpha = 1/4 or 3/4,
16: B = diag(A,-A),   Jn = [[0,-I],[I,0]],   Gamma = diag(I,-I),
17: D = Jn (partial_r+B) = [[0,-partial_r+A],[partial_r+A,0]].
18: ```
19: 
20: These are two graded components of one operator, with the original periodic
21: frame and the opposite-quarter relabelling retained. They are not two boundary
22: faces, two independent vacua, or a new set of four-dimensional particles.
23: The scalar transport `L=partial_r+A` is exactly its chiral block `D_plus`.
24: But `D_plus` maps the positive graded module to the negative one; it is not
25: the entire selfadjoint D on one fixed module.
26: 
27: For `T=exp(-ell B)`, keep BOTH physical boundary faces and both components:
28: 
29: ```
30: G = [[a,c],[c,1-a]],
31: a=(1+exp(-2ell B))^-1, c=(2cosh(ell B))^-1.
32: ```
33: 
34: On the second face the occupation is
35: `n(B)=diag(n(A),1-n(A))`, where `n(A)=(1+exp(2ell A))^-1`.
36: This is the same original graph constructor, not a fitted covariance.
37: Identifying it with a pure charged-CAR state remains an explicit statistical
38: premise, as in PROOF.md. This identification is not derived from P1.
39: 
40: ## 2. The decisive cancellation is analytic, not a cutoff effect
41: 
42: For a complete orthogonal Dirac Cauchy projection C assume its actual normal
43: boundary unitary N satisfies `N C N*=1-C`. For the above finite collar it is
44: `N=diag(-Jn,Jn)`, and the identity follows from the actual graph formula.
45: It is the Lagrangian Cauchy property, not the geometric deck reflection and
46: not a definition of the original admissibility projector.
47: 
48: For bounded implementable generators X,Y, with `[C,X]` and `[C,Y]` Hilbert
49: Schmidt, use the charged-CAR cocycle
50: 
51: `c_C(X,Y)=Tr(C X (1-C) Y C - C Y (1-C) X C)`.
52: 
53: All displayed products are trace class. Cyclicity of products of Hilbert
54: Schmidt off-diagonal blocks gives `c_(1-C)(X,Y)=-c_C(X,Y)`.
55: If X and Y commute with N, unitary covariance also gives
56: `c_(1-C)(X,Y)=c_C(X,Y)`. Consequently **`c_C(X,Y)=0`**.
57: This is a sufficient condition; it does not classify all zero cocycles.
58: 
59: Smooth scalar multiplication on one boundary face, acting on the COMPLETE
60: Dirac fiber, commutes with N. On the circle its off-diagonal commutators are
61: Hilbert Schmidt. Therefore its full-module cocycle vanishes even on ONE face.
62: This cancellation is different from the cancellation BETWEEN the two faces
63: of a SINGLE scalar block established in PROOF.md.
64: 
65: In the product example, each component can be checked separately:
66: 
67: ```
68: c_plus(f,g) = sum_(k>0) k (conj(f_k) g_k - f_k conj(g_k)),
69: c_minus(f,g) = -c_plus(f,g),  c_vector(f,g)=0.
70: ```
71: 
72: The identity uses `n(-A)=1-n(A)` and the infinite telescoping argument already
73: proved for the scalar source. At `f=sin(4theta), g=1-cos(4theta)` these give
74: `-2i,+2i,0`. The commuting-profile Weyl rectangle has phase `exp(2ist)` on
75: the first chiral component, `exp(-2ist)` on the other, and 1 on the full
76: vector module. This does NOT exclude nonzero ordinary correlations, boundary
77: responses, mixed vector/axial currents, or global holonomies of other paths.
78: No finite matrix is asserted to represent the infinite CCR.
79: 
80: This lemma is restricted to the stated charged-CAR, Lagrangian, implementable
81: class. In higher boundary dimensions smooth multipliers need not have Hilbert
82: Schmidt commutators; the unrenormalized trace formula cannot simply be reused.
83: It is not a four-dimensional anomaly, mirror-decoupling, or no-physics theorem.
84: 
85: ## 3. Which geometric unitary is actually allowed by the fixed symbols?
86: 
87: Retaining the original normal and tangential Clifford symbols means that a
88: pointwise unitary u commutes with both `Jn` and `Jn Gamma`. Their common
89: commutant on this two-component fiber is exactly `u=g I2`. Additional internal
90: multiplicity spaces would have their own commutant and are not classified here.
91: 
92: For `g_chi=exp(i chi(r) phi(theta))` the full lift is therefore
93: `U_chi=g_chi I2`, and
94: 
95: ```
96: D_phi = U_chi D U_chi*
97:       = D - i chi_prime phi Jn - chi phi_prime Jn Gamma.
98: ```
99: 
100: Both added multiplication terms together are bounded and Hermitian for smooth
101: real phi and chi on the compact collar. The original Clifford symbols and
102: grading are retained. Its Cauchy transport is
103: `diag(g,g) exp(-ell B)` at the second face, not a transport acting on only one
104: graded component. Both second-face components rotate; Section 2 applies.
105: 
106: The component-selective unitary `diag(g,I)` instead changes Jn and the
107: tangential Clifford symbol for every g != 1. It can be considered with their
108: full transport, or in a chiral operator/measure construction, but cannot be
109: called a scalar gauge perturbation of the SAME fixed full Dirac symbols.
110: Real structure J and the original charged representation still need their
111: actual bundle lift; this two-component computation does not supply them.
112: 
113: ## 4. Fixed boundary conditions and transported ones are different sources
114: 
115: Let Bsa denote an original selfadjoint elliptic boundary trace subspace.
116: With domain `U_chi Dom(D_Bsa)`, D_phi is unitarily equivalent to D_Bsa.
117: If the reflection, reference, J and admissibility complex are transported
118: covariantly as well, the relative spectral traces and eta invariants are
119: unchanged. A nonzero ordinary coordinate derivative of G alone does not
120: establish a physical source variation. The existing covariant-source-jet
121: criterion removes precisely this frame motion.
122: 
123: Keeping Bsa FIXED is nevertheless a legitimate analytic alternative in the
124: displayed compact example: D_phi-D is bounded symmetric, so D_phi on the
125: original selfadjoint domain is selfadjoint. Conjugation by U_chi no longer
126: identifies the same-domain operators unless it preserves Bsa. This by itself
127: does not prove different spectra; a fixed-domain spectral/action response
128: has not been computed here. After conjugating back by U_chi*, its
129: boundary condition is `U_boundary* Bsa`. Thus any such change is a relative
130: boundary attachment, and must be specified as that physical context; one
131: cannot discard its variation in the reference, projector or action.
132: 
133: For the actual reference split, keep the geometric involution R distinct
134: from the Calderon polarization. At fixed R, writing `R_U=U* R U`, exactly
135: 
136: ```
137: D_ref(D_phi,R)=U (D+R_U D R_U)/2 U*,
138: D_rel(D_phi,R)=U (D-R_U D R_U)/2 U*.
139: ```
140: 
141: In particular, if U commutes with the fixed R the reference and relative
142: DIFFERENTIAL expressions are still conjugate; holding R fixed alone does
143: not make the gauge family a physical action variation. Domains remain part
144: of this statement. If `[U,R]!=0`, with `U_t=exp(itF)` and `K=[F,R]`,
145: 
146: ```
147: delta D_ref - i[F,D_ref] = -i (K D R + R D K)/2,
148: delta D_rel - i[F,D_rel] = +i (K D R + R D K)/2.
149: ```
150: 
151: These are the extra reference terms; deleting them is not a fixed-R
152: calculation. For a covariantly transported full admissibility complex its
153: Hodge projector instead obeys `P_t=U P_0 U*`. None of these identities
154: determines the original P1 physical F or the OS operator implementing it.
155: 
156: For the gapped APS sign subspace on a circle, a scalar multiplier and its
157: adjoint preserve the fixed subspace iff g is constant: preserving both Hardy
158: halves forces every nonzero Fourier coefficient of g to vanish. Infinitesimally,
159: `sin(4theta)` sends the negative mode -1 to positive mode 3 with coefficient
160: `1/(2i)`, and `1-cos(4theta)` does so with coefficient `-1/2`.
161: Fixing the four marks therefore does not preserve the original APS subspace.
162: This is NOT a failure of selfadjointness of the bounded perturbation on its
163: old domain. Nor does it rule out a physical boundary drive with that domain.
164: 
165: Two interior extensions chi with the same endpoints differ by a smooth unitary
166: equal to I on both boundary components. It preserves the fixed trace condition
167: and conjugates the two realizations. Therefore even the fixed-domain spectrum
168: depends on the endpoint attachment, not on an arbitrary interior interpolation.
169: 
170: There is a second, stronger trace-space distinction: the one-face endpoint
171: unitary `V=I direct_sum g` preserves the original scalar graph G only for g=I.
172: Indeed its off-diagonal block would require `c g*=c`, and c is injective.
173: This observation concerns the Cauchy trace projection. **It does not identify
174: that projection with Padm on the OS Hilbert space.**
175: 
176: The original physical net requires BOTH A and A* to preserve Ran(Padm),
177: equivalently `[A,Padm]=0` for bounded A on the full OS space. Neither a moving
178: Cauchy graph nor a sign-projector calculation supplies this missing physical
179: operator map. Compression by Padm is explicitly not the definition of the net.
180: 
181: ## 5. The chiral route survives, but its measure is an actual missing datum
182: 
183: The original Gamma already defines the chiral block D_plus. One need not
184: invent an oscillator or a new component label to formulate that route.
185: However replacing the full module by its chiral determinant/quantization is
186: not a change of notation: it selects which field measure and line connection
187: are physically used. That identification is the outstanding task.
188: 
189: The existing source integration result already prevents a shortcut here:
190: `finding:joint-fermionic-source-schur-functional` shows that a DIRECT
191: identification of a primitive trace profile with `-log det K` requires
192: `x f_prime(x)+1=0`. An arbitrary declared spectral profile does not provide
193: that fermionic measure. A separate fermionic action is possible, but its
194: actual kinetic operator, measure and source coupling must then be supplied
195: by the original construction. This is reused prior evidence, not a new test.
196: 
197: For the paired adapted B, Jn pairs every eigenvalue with its negative, so
198: `eta(B)=0`. For the scalar A in the original periodic quarter frame,
199: Hurwitz zeta continuation gives `eta(A)=1-2alpha`, namely +1/2 or -1/2.
200: The two quantities belong to DIFFERENT operators. Even the scalar eta is
201: constant along `g A g*`; its value is not by itself the curvature of the
202: chiral implementer line. There is no license to substitute one for the other.
203: 
204: Original source contracts explicitly require a chiral measure and line WITH
205: connection: `CHIRAL4D.NOMIRROR.01` C1-C6, and
206: `SEAM.DETLINE.UNIFICATION.01`. Their original current manuscript passages and
207: the live CSV ledger still state Open. The Atlas annotation of the former has
208: stale source references; its status was therefore checked directly in the
209: current ledger, not inferred from that annotation. No four-dimensional part
210: of those contracts is proved by this boundary calculation.
211: Their four-dimensional requirements are not imposed as prerequisites for
212: further one-dimensional boundary work. The immediate missing map is already
213: the boundary source/measure/connection identification in the original datum.
214: 
215: ## 6. Consequence for the solution search
216: 
217: The automatic route "full P1 Calderon graph -> same scalar one-face current
218: phase" fails in the stated complete Dirac/CAR realization. Restoring the
219: omitted graded component cancels its central phase. The previous scalar
220: bridge is correct on its stated scalar/chiral source, and remains conditional.
221: 
222: The next indispensable original map is now more specific: the P1 real/graded
223: source and its physical admissible measure must select the chiral block (or
224: supply a compensating bulk line/inflow) and identify its connection with the
225: original charged CAR/E8 source, while retaining the actual boundary attachment,
226: reference and A/A*-admissibility. A declaration of a new projector or fitted
227: coupling would not establish that map.
228: 
229: Native Hamming/E8/J, quartic4/5, erasure20, primary20 carry, all eight source
230: preimages, original time and winding are unchanged. No finite code-closure
231: condition is added. No T1-T8 goal, event-selection rule or full solution closes.
232: 
233: ## Sources and verification
234: 
235: - Original full product Dirac: `seam-full-collar-reconstruction-20261015/PROOF.txt:21-61`.
236: - Original P1 datum, primitive action and physical net:
237:   `documents/archive--tfpt-45--source_extracts--01_boundary_kernel_source/sections/001-section-primitive-core-and-carrier-interface-handoff.tex:65-80,302-343`.
238: - Original full selector: `documents/archive--tfpt-45--source_extracts--04_qft_source/sections/002-section-closure-theorems-from-the-admissibility-complex.tex:12-123`.
239: - Existing frame subtraction: `seam-collar-multifield-20261016/P1-COVARIANT-INSERTION.txt:26-146`.
240: - Existing joint source-measure identification test: `seam-collar-multifield-20261016/PROOF.txt:271-326`.
241: - Original open chiral and line contracts: `documents/tfpt_research_contracts/sections/015-source.tex:235-266`, `017-source.tex:239-285`.
242: - [Baer and Ballmann, arXiv:1307.3021v2](https://arxiv.org/abs/1307.3021), Lemma 3.2/Remark 3.3, Theorems 4.11-4.12: adapted operator, paired spectrum, boundary domains.
243: - [Langmann, JMP35 (1994), arXiv:hep-th/9305014](https://arxiv.org/abs/hep-th/9305014), equations 31-34: implementable CAR currents and trace-class cocycle.
244: 
245: `check_dirac_lift.py` reuses the existing graph constructor and checks the
246: normal-complement identity, full/component cocycles, symbol commutant and
247: differential lift exactly. Finite matrices are controls of those analytic
248: identities, not a numerical proof of an infinite field theory.
```

## experiments/theory-contracts/original-admissible-source-closure-20261025/NORMAL-INDEX-TRANSPORT.txt

Original SHA256 f66b65fb9e23a2fe97c95ad924bd6ee39ea9c182111031392010cf4507620099; Zeilen 1 bis 224.

```text
1: NORMALE INDEXLINIE UND VOLLSTAENDIGE KREISQUELLE
2: ===============================================
3: 25. Oktober 2026
4: MATH.ORIGINAL-SEAM.NORMAL-INDEX-TRANSPORT.01
5: MATH.ORIGINAL-SEAM.NORMAL-HOLONOMY-CRITERION.01
6: MATH.ORIGINAL-SEAM.FULL-PRODUCT-TRACECLASS.01
7: 
8: Ergebnis und erste zusaetzliche Voraussetzung
9: --------------------------------------------
10: Die normale Kupplungssphaere muss nicht mit dem tangentialen Quellkreis
11: gleichgesetzt werden. Es gibt einen natuerlichen analytischen Indextransport,
12: wenn dieselbe Quelle tatsaechlich einen entsprechenden Produktoperator traegt.
13: Eine solche Operatoridentifikation wird in den geprueften Originalstellen
14: nicht definiert. Die folgenden Saetze bestimmen exakt, was sie leisten wuerde,
15: und welche Quellantwort sie nicht automatisch erhaelt. Es wird keine neue
16: physische Quelle gewaehlt oder auf einen Zielwert angepasst.
17: 
18: Die erste Zusatzvoraussetzung ist D_N=D_spin(S2) gekoppelt an L2=det E2.
19: Die vorhandene bosonische B_E2 und die Abschnittsrechnung H0(O(1)) definieren
20: diesen Spinoperator nicht. Danach braucht es eine originale normale Familie
21: ueber dem Quellkreis und deren Produkt oder Familienverbindung.
22: 
23: 1. Welcher normale Operator hat eine einzelne Nullmode?
24: ------------------------------------------------------
25: Auf der orientierten Spin S2=CP1 ist K^(1/2)=O(-1). Fuer die originale
26: Determinantenlinie L2=O(1) folgt beim echten getwisteten Spinoperator
27: 
28:   ker D_(N,L2)^+ = H0(O(-1) tensor O(1)) = H0(O) = C,
29:   ker D_(N,L2)^- = H1(O) = 0.                                (1)
30: 
31: Die Normalnullmode ist eine kanonische Linie; ein normierter Erzeuger chi
32: ist nur bis auf Phase bestimmt. Keine Kreis Fouriermode wurde ausgewaehlt.
33: 
34: Fuer den vollen E2 Twist ist die Aussage staerker als seine Determinante:
35: E2=O(k) direct_sum O(1-k), k>=1, hat weiterhin det E2=O(1), aber
36: 
37:   dim ker D_(N,E2)^+ = k,
38:   dim ker D_(N,E2)^- = k-1.                                   (2)
39: 
40: Sein Index ist immer eins. Dagegen hat der skalare beziehungsweise komplexe
41: Spin-c Dolbeaultoperator mit O(1) den Index chi(O(1))=2 und H0 Dimension2.
42: Die Rechnung eines schwachen Dubletts und die Spin Indexlinie sind somit
43: verschiedene Operatorrealisierungen derselben Gradangabe. Der bestehende
44: Higgs/Carrier Audit wird wiederverwendet; aus (1) folgt keine neue physische
45: Herleitung des Higgs oder des Rang2 Traegers.
46: 
47: 2. Exakter Transport, sobald der Originaloperator die Produktform hat
48: --------------------------------------------------------------------
49: Seien B_a=-i partial_theta+a auf H1_per(S1), 0<a<1, und ein gegebener
50: selbstadjungierter elliptischer D_N auf S2 mit normaler Graduierung gamma_N,
51: 
52:   {gamma_N,D_N}=0,   gamma_N^2=I.
53: 
54: Auf der echten Produktdomaene H1 der Kreis mal Sphaeren Spinoren sei
55: 
56:   B_prod=B_a tensor gamma_N + I tensor D_N.                    (3)
57: 
58: Die Graduierung stammt vom GERADEN normalen Raum. Der urspruengliche
59: ungerade skalare Kreis braucht keine erfundene eigene Graduierung.
60: Fuer D_N chi=0, gamma_N chi=+chi und ||chi||=1 definiere
61: 
62:   V_chi f=f tensor chi,    F=V_chi V_chi*.
63: 
64: Dann V_chi*V_chi=I und auf ganzen Operatorbereichen
65: 
66:   B_prod V_chi=V_chi B_a.                                    (4)
67: 
68: F reduziert B_prod. Daher gilt fuer jede beschraenkte borelsche Funktion h
69: 
70:   F h(B_prod) F = V_chi h(B_a) V_chi*.
71: 
72: Insbesondere werden die GANZE Zeit e^(it B_a), die Polarisation und jede
73: treue endliche-beta Kovarianz C_beta=(I+exp(beta B_a))^-1 transportiert.
74: Der vorhandene Kreisloop u=M_z erfuellt
75: 
76:   (u tensor I) V_chi = V_chi u.
77: 
78: Der neue Trager F hat unendlichen Rang, denn alle tangentialen Fouriermoden
79: bleiben erhalten. Er ist keine finite Kompression des alten Kreises.
80: Auf diesem reduzierenden Bild folgt der schon bewiesene relative Faktor1-z
81: fuer C_beta und allgemein fuer die entsprechende Spurklasse. Eine negative
82: Normalchiralitaet wuerde -B_a tragen; das Vorzeichen ist zu erhalten.
83: 
84: Der Spektralfluss desselben gegebenen Produktes ist ebenfalls exakt. Bei
85: B_s=(B_a+s)gamma_N+D_N und einem Nichtnullpaar +/-lambda ist der Block
86: 
87:   H_x^lambda=[[x,lambda],[lambda,-x]],  x=n+a+s,
88:   (H_x^lambda)^2=(x^2+lambda^2)I.
89: 
90: Er hat keine Nulldurchgaenge. Nur normale Nullmoden tragen bei:
91: 
92:   SF(B_s,0<=s<=1)=dim ker D_N^+ - dim ker D_N^-
93:                 =ind D_N^+.                                 (5)
94: 
95: Das ist ein ausreichender Pushforward, keine Behauptung seiner bereits
96: erfolgten urspruenglichen oder physikalischen Auswahl.
97: 
98: 3. Verbindung der Indexlinie: exaktes Holonomiekriterium
99: -------------------------------------------------------
100: Bei einer echten Familie ist die horizontale Indexlinienverbindung zu
101: behalten. Schon in der guenstigen exakt reduzierenden Rang1 Situation hat
102: der effektive Kreisoperator die Form
103: 
104:   B_A=-i partial_theta+A(theta),   A reell glatt,
105:   Dom B_A=H1_per,   Abar=(1/(2pi)) integral A.
106: 
107: Bei festem Kreiszeitmass und u=M_z existiert ein glatter periodischer
108: Multiplikator g mit B_A M_g=M_g B_a genau dann, wenn
109: 
110:   Abar-a in Z.                                               (6)
111: 
112: Beweis: Setze g=exp(i chi), chi'=a-A. Die Gleichung ist genau
113: chi'+A=a. g ist periodisch genau bei integral(a-A) in2pi Z.
114: Umgekehrt erzwingt jede periodische Loesung diese Integralbedingung.
115: Der Multiplikator erhaelt H1 und kommutiert mit u. Borel Funktionalkalkuel
116: transportiert daher Zustand und Zeit auf dem gegebenen Quellraum. Dies ist
117: die Anwendung des schon klassifizierten skalaren Erstordnungsfalls, keine
118: erneute allgemeine Klassifikation. Feste Clockmarken und eine urspruengliche
119: Reflexion muessen bei ihrer Anwendung ebenfalls transportiert werden.
120: 
121: Das vertikale Datum bestimmt (6) nicht: Die triviale normale Familie mit
122: festem D_N darf horizontal mit einer flachen Linie der Verbindung
123: partial_theta+i t getensort werden. Auf jeder normalen Faser bleiben L2,
124: c1, D_N, sein Kernel und sein Index gleich. Die induzierte Kreisphase
125: veraendert sich um exp(-2pi i t). t modulo Z ist ein freies Verbindungsdatum
126: SOLANGE die urspruengliche horizontale Quellenregel nicht festliegt.
127: Dies sind keine behaupteten zwei vollstaendigen P1 Modelle; der Test zeigt
128: nur die Informationsgrenze der vertikalen Gradangabe. Das A4 Spinresultat
129: bleibt erhalten und ersetzt keinen unbewiesenen zusaetzlichen Wilsonfaktor.
130: 
131: 4. Der volle Produktwechsel ist nicht derselbe Fredholm Determinant
132: ------------------------------------------------------------------
133: Ein Indextransport liefert nicht automatisch einen gewoehnlichen relativen
134: Fredholmdeterminanten auf dem dreidimensionalen Gesamtprodukt. Hier laesst
135: sich das direkt beweisen. Behalte nur EINEN tangentialen Fourierindex n
136: und betrachte alle positiven Normalwerte lambda_j. Fuer
137: 
138:   P_x^lambda=(I-H_x^lambda/sqrt(x^2+lambda^2))/2
139: 
140: haben P_(x+1)^lambda-P_x^lambda zwei Singulaerwerte
141: sin(Delta theta/2), wobei Delta theta der Winkel der normierten Vektoren
142: (lambda,x) und (lambda,x+1) ist. Somit
143: 
144:   ||P_(x+1)^lambda-P_x^lambda||_1
145:     =2 sin(Delta theta/2)
146:     >= sin Delta theta
147:     =lambda/[sqrt(x^2+lambda^2) sqrt((x+1)^2+lambda^2)]
148:     >=1/(2lambda)                                           (7)
149: 
150: fuer lambda>=max(1,|x|,|x+1|). Das elliptische zweidimensionale D_N hat
151: positive Weylfolge lambda_j asymptotisch const sqrt(j), mit Vielfachheiten
152: gezaehlt. Daher divergiert bereits die Summe aus (7) auf diesem einen
153: Kreisindex. Der volle Unterschied der Produktpolarisationen ist nicht L1.
154: 
155: Im runden Grad1 Monopolfall ist dies auch ganz explizit: lambda_l=sqrt(l(l+1))
156: mit Vielfachheit2l+1 fuer l>=1. Jede Normalstufe liefert ab hinreichendem l
157: mindestens (2l+1)/(2sqrt(l(l+1)))>1 zur unteren Schranke. Die Divergenz ist
158: damit kein numerischer Rang oder Cutoff Effekt.
159: 
160: Der reduzierte Kreis aus (4) liegt weiter in seiner bewiesenen Spurklasse.
161: Der ganze Produktoperator braucht dagegen einen eigenen Regularisierungs
162: und Antwortvertrag. Ein Grad1 Index allein rechtfertigt dort nicht die
163: Verwendung des eindimensionalen gewoehnlichen Fredholmdeterminanten.
164: 
165: Auch die treue volle KMS Kovarianz aendert diese Schattenklasse nicht:
166: Fuer endliches beta ist C_beta(B_prod)-P0 spurklassig, denn der elliptische
167: kompakte Produktoperator hat exponentiell summierbare thermische Enden.
168: Waere U C_beta U*-C_beta fuer die volle Kreiswindung U dennoch L1, dann
169: waere durch Addieren der beiden spurklassigen Kovarianzkorrekturen auch
170: UP0U*-P0 in L1. Das widerspricht (7). Der alte thermische Kreissatz bleibt
171: auf dem reduzierten Bild richtig; er wird dadurch nicht zum vollen 3D Satz.
172: 
173: 5. Null Index der massiven Paare bedeutet keine verschwindende Antwort
174: ---------------------------------------------------------------------
175: Fuer einen massiven Produktkanal sei A_(a,lambda)=B_a^2+lambda^2. Gegen a0
176: ist sein relatives positives Kreisspektrum exakt
177: 
178:   det_zeta A_(a,lambda)/det_zeta A_(a0,lambda)
179:     =[cosh(2pi lambda)-cos(2pi a)]
180:       /[cosh(2pi lambda)-cos(2pi a0)].                        (8)
181: 
182: Die Formel folgt etwa durch symmetrische Paarung der Kreisprodukte und die
183: Cotangens Partialbruchformel. Ihre logarithmische Ableitung lautet
184: 
185:   partial_a Log det_zeta A_(a,lambda)
186:     =2pi sin(2pi a)/[cosh(2pi lambda)-cos(2pi a)].             (9)
187: 
188: Bei a=1/4 ist sie exakt2pi/cosh(2pi lambda)>0 fuer jedes endliche lambda.
189: Dieser Kanal hat in (5) trotzdem Spektralfluss null. Auf dem Zweierblock
190: von B_prod^2 kommt das skalare positive Spektrum zweimal vor; eine korrekt
191: definierte Determinantennorm behaelt den entsprechenden Faktor.
192: 
193: a ist hier die SPEKTRALE HOLONOMIE, nicht die elektromagnetische Kopplung
194: alpha. (9) widerlegt keine urspruengliche alpha Wardidentitaet. Es widerlegt
195: nur den Schluss, die massiven Beitraege seien wegen Index null automatisch
196: konstant. Eine volle Quillen/EM Antwort muss diese Beitraege im selben
197: relativen Mass und Renormierungsvertrag mitfuehren oder ihre Aufhebung
198: beweisen. Eine graduierte Indexspur darf die originale tr_adm nicht ersetzen.
199: Schurfaktorisierung ist ohne Zusatzbeweis nur endlich beziehungsweise fuer
200: passende relative Fredholmoperatoren multiplikativ; getrennte Zeta Faktoren
201: koennen Gluingterme und eine multiplikative Anomalie tragen.
202: 
203: Quellen, Wiederverwendung und Grenzen
204: --------------------------------------
205: * NORMAL-CLUTCH-TO-SOURCE-PUSHFORWARD.txt und
206:   TRANSVERSE-INDEX-EM-RESPONSE.txt: unabhaengige Original und Operatorreviews.
207: * Der Bott Klassenweg war bereits am30.09.2026 in
208:   source-rule-search-20260930/BOTT_CLASS_ORIGIN.md bekannt. Neu hier sind die
209:   konkrete spaetere L2 Spin Indexlinie, ihr vollstaendiger Operatortransport,
210:   das induzierte Holonomiekriterium und die explizite volle Spurklassengrenze.
211: * Jante/Schroers, arXiv:1312.4879, Abschnitte2.1-2.4: getwisteter Spin Dirac
212:   auf S2, Spinverschiebung, Zero Mode und Rotationsdarstellung.
213: * Borokhov/Kapustin/Wu, hep-th/0206054, Abschnitt4.1 und AnhangA: normales
214:   Monopolspektrum. Es wird nur dessen explizite Spektralformel verwendet,
215:   nicht die dortige 3D QED als neues TFPT Modell.
216: * Freed, dg-ga/9505002: die volle Determinantenlinie traegt ihre geometrische
217:   Verbindung. Ein blosser Zahlenindex liefert deren Antwort nicht.
218: 
219: Die mathematischen Aussagen gelten in ihren bezeichneten Klassen. Der
220: Originaltext instanziiert D_N, horizontale Familie und Quelle aus (3) nicht.
221: P_adm wird dort auch nicht als F aus (4) konstruiert. Eine urspruengliche
222: EM Quellenvariation, der B gamma Faktor und der volle Restquotient werden
223: hier nicht daraus abgeleitet. Gesamtverdict PARTIAL; keine physische
224: Gate Schliessung und keine Aenderung des Originalledgers.
```

## experiments/theory-contracts/original-admissible-source-closure-20261025/NORMAL-CONNECTION-MARKS-COVER.txt

Original SHA256 33448654daa781525df039173b862274036f8ef2c267865afec6555c12b4c9de; Zeilen 1 bis 76.

```text
1: NORMALE VERBINDUNG, TETRAEDER UND GEMEINSAME COVERBILDER
2: =====================================================
3: 25. Oktober 2026
4: MATH.ORIGINAL-SEAM.NORMAL-CONNECTION.01
5: MATH.ORIGINAL-SEAM.TETRAHEDRAL-MODULI.01
6: MATH.ORIGINAL-SEAM.ELLIPTIC-COVER-IMAGE.01
7: 
8: Frage und Abbruchkriterium
9: -------------------------
10: Liefert eine schon vorhandene geometrische Verbindung die noch fehlende
11: gemeinsame Quellenabbildung? Zuerst werden die tatsaechlichen Operatoren
12: und markierten Kurven verglichen. Ein gleicher Zahlenindex oder Phasenwert
13: genuegt nicht. Der direkte Ansatz wird verworfen, sobald der notwendige
14: Kommutator oder das markierte Kreuzverhaeltnis nicht passt. Ein bereits
15: vorhandener groesserer Cover bleibt dabei als andere Verbindung erhalten.
16: Es wird kein neuer physischer Operator, Zustand oder Kopplungswert gewaehlt.
17: 
18: 1. Vollstaendiges Kriterium fuer eine mitbewegte reduzierende Kernfaser
19: --------------------------------------------------------------------
20: Objektklasse: H=L2(S1,C^r), B_A=-i partial_theta+A(theta), Dom=H1_per,
21: A glatt, periodisch und hermitesch. P(theta) ist ein glatter periodischer
22: orthogonaler Projektor festen Ranges, Q=I-P. P bezeichnet hier eine
23: mitbewegte Faser, keine ausgefuehrte Messung. A und P sind noch keine aus
24: P1 ausgewaehlten physischen Daten. Das Hauptsymbol ist ausdruecklich scalar.
25: 
26: Multiplikation mit P erhaelt H1. Auf dieser ganzen Domain gilt
27: 
28:   [B_A,P]=-i P' + [A,P].                                    (1)
29: 
30: Das Bild von P reduziert B_A genau dann, wenn (1) null ist. Aus P^2=P
31: folgen P'=P'P+PP' und PP'P=QP'Q=0. Deshalb
32: 
33:   [i[P',P],P]=iP'.
34: 
35: Saemtliche reduzierenden Verbindungen dieser Klasse sind daher exakt
36: 
37:   A=i[P',P]+PAP+QAQ.                                        (2)
38: 
39: Die beiden letzten Terme koennen beliebige glatte hermitesche Diagonalbloecke
40: sein. Umgekehrt laesst jede Loesung von (1) nach Abzug von i[P',P] nur diese
41: Diagonalbloecke uebrig. Das beweist Notwendigkeit und Hinreichen, nicht nur
42: einen moeglichen Transport. Selbstadjungiertheit folgt aus dem freien
43: Kreisoperator plus beschraenkter hermitescher Multiplikation. P und Q
44: erhalten die Domain und kommutieren mit dem Operator, also auch mit seinen
45: Resolventen. Es handelt sich um echte Reduktion statt blosser Kompression.
46: 
47: Fuer Rang1 waehle einen glatten periodischen normierten Rahmen chi fuer P.
48: Eine solche Wahl existiert, weil jede komplexe Linie ueber S1 trivial ist.
49: Vf=chi f ist unitaer auf das reduzierende Bild. Es gilt exakt auf H1
50: 
51:   B_A V=V(-i partial_theta+a_eff),
52:   a_eff=chi* A chi-i chi*chi'.                               (3)
53: 
54: Damit folgt der gesamte beschraenkte Borel Funktionalkalkuel und der
55: vorherige volle Kreiszustandtransport unter seinen dortigen Voraussetzungen.
56: Ein anderer periodischer Rahmen aendert a_eff nur um den zugehoerigen
57: Phasenableitungsterm. Das bestehende Holonomiekriterium wird wiederverwendet.
58: 
59: Die einfachste entscheidende Folgerung ist
60: 
61:   A=a I  und exakte Reduktion  =>  P'=0.                     (4)
62: 
63: Ein bewegter Bottprojektor reduziert also den unveraenderten skalaren
64: Kreis nicht automatisch. Die erforderliche nichtdiagonale Verbindung (2)
65: muss wirklich aus der Originalquelle stammen. Sie wird hier nicht frei
66: eingefuehrt. Bei einem wirklichen Normaloperator sind ausserdem gemeinsame
67: Domain, Graduierung und Kernprojektion nachzuweisen; eine adiabatische
68: Naeherung ersetzt diese exakte Aussage nicht. (2) ist die Standardstruktur
69: des Kato Transports, hier auf die aktuelle Quellenfrage angewandt.
70: 
71: 2. Die vier E6 Richtungen tragen eine echte Dreipunkt Viertelphase
72: ----------------------------------------------------------------
73: Das bestehende CUTS.txt:250-276 liefert im chiralen (16,4) Block
74: 
75:   T={(+++),(+--),(-+-),(--+)}/sqrt3.
76: 
```

## experiments/theory-contracts/seam-joint-source-origin-audit-20261016/HIGGS_VARIATION_PROOF.txt

Original SHA256 84004fc583641a52096c8571844aaed825d16d8165635eafd1a6b2562708e6be; Zeilen 135 bis 182.

```text
135: 6. Derive the actual existing finite-triple Higgs dependence, leaving inputs visible
136: 
137: The finite path is read from the owning implementation, not from an inferred
138: Atlas annotation:
139:   v252_full_finite_triple.py:64-69 explicitly enumerates nu/e and u/d, with3 colors;
140:   :86-99 defines dirac_block(Yu,Yd,Ye,Ynu) by inserting those four matrices;
141:   :139-168 fixes rep(lambda,q,m) for C+H+M3 with the weak/color actions;
142:   v254_inner_fluctuations.py:80-87 uses random Yukawa blocks for its example.
143: No such random block or chosen physical Yukawa value is used in this annex.
144: 
145: For one sector with the GIVEN right-to-left seed
146:   M=diag(Y_up,Y_down),
147: let e_R be the represented lambda=1,q=0 element and a_q the represented
148: lambda=0, quaternion q element. The actual one-form has LR block
149:   (a_q[D_F,e_R])_LR=q M,
150: where
151:   q=[[phi1,phi2],[-conjugate(phi2),conjugate(phi1)]].
152: Hermitian completion supplies M* q* in the reverse block. Including the seed
153: replaces q by H=I+q, which has the same quaternion coordinate space. Thus
154:   M_q(H)=[[phi1 Yu, phi2 Yd],[-conjugate(phi2) Yu,conjugate(phi1) Yd]],
155: with an identical color copy already present in the input representation.
156: The lepton formula uses Ynu,Ye. The physical full real-triple completion and
157: Majorana requirements retain their separate first-order conditions.
158: 
159: This also describes EVERY particle LR one-form for this supplied SM action:
160: if b acts as q_b on the left and r_b=diag(lambda_b,conjugate(lambda_b)) on the
161: right, the commutator and left multiplication give
162:   (a[D_F,b])_LR=q_a(M r_b-q_b M)=q_a(r_b-q_b) M.
163: The family matrices commute with r_b because its entries are scalars on the
164: family index. Both r_b and q_b are quaternions, hence q_a(r_b-q_b) is one.
165: Arbitrary sums retain this structure, and b=e_R realizes every q M. No Yukawa
166: value was chosen to obtain this identity. The Majorana sector and real
167: completion remain separate as stated above.
168: 
169: The scalar interaction derivative is therefore proportional to the EXISTING
170: Y input. Inner fluctuation does not supply a missing numerical or structural
171: Yukawa seed. For D_F=0, all [D_F,b] and therefore all finite one-forms vanish.
172: For a fixed represented algebra, every block reducing both D_F and the algebra
173: also reduces every a[D_F,b]. None of this selects an absent 3+2 representation.
174: 
175: The independent block formula was checked against the actual original
176: dirac_block and rep code on the complete72-real-coordinate basis of the four
177: complex3x3 input matrices and all4 quaternion coordinates. All288 block
178: identities, comprising663552 Gaussian-integer entries, agree exactly. These
179: coordinate probes certify a linear identity; they are not chosen physical
180: couplings or an origin test. The zero-seed control is likewise not claimed as
181: a P1/P2-admissible alternative world. We do not rerun a target-mass inverse-KMS
182: construction as a Yukawa derivation.
```

## verification/v252_full_finite_triple.py

Original SHA256 820254440e178430422e50605067775656236602996307f67c9e69124ba5d163; Zeilen 1 bis 168.

```text
1: """v252 -- PS.DIRAC.02: the FULL 96-dimensional finite spectral triple
2: (A_F, H_F, D_F, J_F, gamma_F) of the carrier, built explicitly, with the
3: non-commutative-geometry axioms verified by direct computation.  This advances
4: CONTRACT.QFT4D.DIRAC.01 (v250) from a contract listing 7 open obligations to a
5: concrete object on which 5 of them are discharged to [E].
6: 
7: Hilbert space.  H_F = H_particle (+) H_antiparticle, dim = 2 x (3 gen x 16) = 96.
8: One generation = the SO(10) 16 (v245): per generation the 16 left+right Weyl
9: fermions
10: 
11:     nu_L, nu_R, e_L, e_R   (colour singlets)
12:     u_L, u_R, d_L, d_R     (x 3 colours)            -> 4 + 12 = 16,  x3 gen = 48,
13:                                                        x2 (particle (+) antiparticle) = 96.
14: 
15: Dirac operator.  D_F = [[S, T],[T^dag, conj S]] with
16:     S = the Dirac/Yukawa block (nu_L<->nu_R, e_L<->e_R, u_L<->u_R, d_L<->d_R),
17:     T = the Majorana block (nu_R particle <-> nu_R antiparticle = the sigma term).
18: 
19: Real structure / grading.  J_F = (particle<->antiparticle swap) . complex conj;
20: gamma_F = chirality (+1 left, -1 right on particles; flipped on antiparticles).
21: 
22: Algebra A_F = C (+) H (+) M_3(C) acts as a bimodule: on particles via (lambda, q)
23: [colour-trivial], on antiparticles via (lambda, m) [weak-trivial]; J implements the
24: opposite (right) action.  This split is exactly what makes order-zero hold.
25: 
26:   [E] 1. DIMENSION.  dim H_F = 96 = 2 x 3 x 16 = 2 x Omega_adm (v245 carrier count).
27:   [E] 2. D_F HERMITIAN and ODD: D_F = D_F^dag and D_F gamma = -gamma D_F.
28:   [E] 3. REALITY (J).  J^2 = +1 and J D_F = D_F J  -> the real structure.
29:   [E] 4. GRADING (gamma).  gamma^2 = 1, [gamma, pi(a)] = 0 (even), J gamma = -gamma J.
30:   [E] 5. KO-DIMENSION 6.  (J^2, JD=DJ, Jgamma=-gammaJ) = (+1, +, -) = KO-dim 6 mod 8
31:         (Chamseddine-Connes-Marcolli), the physical value for the finite SM/PS geometry.
32:   [E] 6. ORDER-ZERO.  [pi(a), J pi(b) J^-1] = 0 for all a,b in A_F (the right/colour
33:         action commutes with the left/weak action -- the bimodule split).
34:   [E] 7. FIRST ORDER HOLDS for the SM algebra.  [[D_F, pi(a)], J pi(b) J^-1] = 0 for
35:         all a,b in the SM algebra C(+)H(+)M_3, INCLUDING the full Majorana term -- the
36:         Standard-Model finite geometry satisfies the order-one condition (van Suijlekom).
37:   [E] 8. FIRST ORDER VIOLATED for the Pati-Salam algebra -- exactly by the Majorana.
38:         Enlarging C(+)H(+)M_3 to the Pati-Salam algebra (an SU(2)_R that pairs nu_R
39:         with e_R) leaves order-one intact while the Majorana is off, but BREAKS it once
40:         the Majorana(sigma) term is on; the violation is supported EXACTLY on the
41:         right-handed lepton doublet {nu_R, e_R}.  This is the Chamseddine-Connes-
42:         van Suijlekom "beyond first order" mechanism: dropping order-one + inner
43:         fluctuations promote the SM to Pati-Salam and generate sigma (v251), here on
44:         the full 96-dim triple.
45:   [E] 9. SPECTRUM = MASSES.  the eigenvalues of D_F reproduce the physical fermion
46:         spectrum: charged Dirac eigenvalues = +/- m_f, and the neutrino block gives
47:         the type-I seesaw m_light ~ m_D^2 / M_R.
48:   [C] 10. POINCARE DUALITY.  the intersection (multiplicity) form of the realised
49:         irreps is non-degenerate (det != 0) -- Poincare-duality compatible; the
50:         canonical normalisation is convention-dependent, hence [C].
51:   [O] 11. RESIDUAL.  orientability (Hochschild orientation cycle), the no-junk
52:         (vanishing of junk 1-forms) condition and the full spectral-action heat-kernel
53:         expansion remain the open part of CONTRACT.QFT4D.DIRAC.01.
54: 
55: Status: [E] for items 1-9 (the explicit triple + KO-6 + order-zero + first-order
56: holds(SM)/violated(PS) + mass spectrum), [C] for Poincare duality, [O] for
57: orientability/no-junk/spectral action.  Python-only (numpy).
58: """
59: import numpy as np
60: 
61: from tfpt_constants import check, summary, reset, Omega_adm
62: 
63: NG = 3                      # generations
64: # one-generation field list: (name, chirality, colour)   colour 0 for leptons
65: GEN_FIELDS = (
66:     [("nu", "L", 0), ("nu", "R", 0), ("e", "L", 0), ("e", "R", 0)]
67:     + [(f, ch, c) for c in range(3) for f in ("u", "d") for ch in ("L", "R")]
68: )
69: # -> nu,e (4) + (u/d)x(L/R)x3colour (12) = 16 per generation
70: 
71: 
72: def build_index():
73:     P = []
74:     for g in range(NG):
75:         for (name, ch, c) in GEN_FIELDS:
76:             P.append((name, ch, c, g))
77:     idx = {f: i for i, f in enumerate(P)}
78:     return P, idx
79: 
80: 
81: P, IDX = build_index()
82: NP = len(P)                 # 48 particle states
83: NH = 2 * NP                 # 96 full
84: 
85: 
86: def dirac_block(Yu, Yd, Ye, Ynu):
87:     """particle 48x48 Yukawa block S (Hermitian): L<->R per field/colour."""
88:     S = np.zeros((NP, NP), complex)
89:     table = {"u": Yu, "d": Yd, "e": Ye, "nu": Ynu}
90:     for (name, ch, c, g) in P:
91:         if ch != "L":
92:             continue
93:         Y = table[name]
94:         for gj in range(NG):
95:             i = IDX[(name, "L", c, g)]
96:             j = IDX[(name, "R", c, gj)]
97:             S[i, j] = Y[g, gj]
98:             S[j, i] = np.conjugate(Y[g, gj])
99:     return S
100: 
101: 
102: def full_D(Yu, Yd, Ye, Ynu, MR):
103:     """D_F = [[S, T],[T^dag, conj S]] ; T = Majorana on nu_R (particle<->antiparticle)."""
104:     S = dirac_block(Yu, Yd, Ye, Ynu)
105:     T = np.zeros((NP, NP), complex)
106:     for g in range(NG):
107:         for gj in range(NG):
108:             i = IDX[("nu", "R", 0, g)]
109:             j = IDX[("nu", "R", 0, gj)]
110:             T[i, j] = MR[g, gj]
111:     D = np.zeros((NH, NH), complex)
112:     D[:NP, :NP] = S
113:     D[NP:, NP:] = np.conjugate(S)
114:     D[:NP, NP:] = T
115:     D[NP:, :NP] = T.conj().T
116:     return D
117: 
118: 
119: def grading():
120:     gp = np.array([1.0 if ch == "L" else -1.0 for (_, ch, _, _) in P])
121:     return np.diag(np.concatenate([gp, -gp]))      # antiparticles: opposite chirality
122: 
123: 
124: def Kswap():
125:     K = np.zeros((NH, NH))
126:     K[:NP, NP:] = np.eye(NP)
127:     K[NP:, :NP] = np.eye(NP)
128:     return K
129: 
130: 
131: def Japply(v, K):
132:     return K @ np.conjugate(v)                       # antilinear J = swap . conj
133: 
134: 
135: def quaternion(a, b):
136:     return np.array([[a, b], [-np.conjugate(b), np.conjugate(a)]], complex)
137: 
138: 
139: def rep(lam, q, m):
140:     """pi(a), a=(lam in C, q in H (2x2), m in M_3(C)).  Bimodule split:
141:     particles -> (lam,q) colour-trivial ; antiparticles -> (lam,m) weak-trivial."""
142:     pi = np.zeros((NH, NH), complex)
143:     # ---- particle block: weak/hypercharge action, identity on colour ----
144:     for g in range(NG):
145:         # lepton doublet (nu_L,e_L) <- q ;  nu_R<-lam, e_R<-conj(lam)
146:         nl, el = IDX[("nu", "L", 0, g)], IDX[("e", "L", 0, g)]
147:         pi[nl, nl], pi[nl, el] = q[0, 0], q[0, 1]
148:         pi[el, nl], pi[el, el] = q[1, 0], q[1, 1]
149:         pi[IDX[("nu", "R", 0, g)], IDX[("nu", "R", 0, g)]] = lam
150:         pi[IDX[("e", "R", 0, g)], IDX[("e", "R", 0, g)]] = np.conjugate(lam)
151:         for c in range(3):
152:             ul, dl = IDX[("u", "L", c, g)], IDX[("d", "L", c, g)]
153:             pi[ul, ul], pi[ul, dl] = q[0, 0], q[0, 1]
154:             pi[dl, ul], pi[dl, dl] = q[1, 0], q[1, 1]
155:             pi[IDX[("u", "R", c, g)], IDX[("u", "R", c, g)]] = lam
156:             pi[IDX[("d", "R", c, g)], IDX[("d", "R", c, g)]] = np.conjugate(lam)
157:     # ---- antiparticle block: colour action m on quarks, lam on leptons ----
158:     off = NP
159:     for g in range(NG):
160:         for (name, ch, c, gg) in [f for f in P if f[3] == g]:
161:             i = off + IDX[(name, ch, c, g)]
162:             if name in ("nu", "e"):
163:                 pi[i, i] = lam
164:             else:                                    # quark: colour matrix m
165:                 for c2 in range(3):
166:                     j = off + IDX[(name, ch, c2, g)]
167:                     pi[i, j] = m[c, c2]
168:     return pi
```
