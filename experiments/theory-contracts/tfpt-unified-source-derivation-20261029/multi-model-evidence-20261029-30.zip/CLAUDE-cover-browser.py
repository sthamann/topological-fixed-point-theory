import numpy as np, mpmath as mp
N=40; d=5
n1=np.arange(-N,N+1)          # summand alpha=1/4
n2=-n1-1                      # summand alpha=3/4 (partner window)
E1=2*(n1+0.25); E2=2*(n2+0.75)
# basis order: [summand1 modes x C^d , summand2 modes x C^d]
L=len(n1); dim=2*L*d
Bc=np.diag(np.concatenate([np.repeat(E1,d),np.repeat(E2,d)]))
# J' = M_{e^{-i theta}} K S : (e_n,0)x c -> (0,e_{-n-1}) x conj(c), (0,e_m)x c -> (e_{-m-1},0) x conj(c)
U=np.zeros((dim,dim))
idx1={n:i for i,n in enumerate(n1)}; idx2={m:i for i,m in enumerate(n2)}
for i,n in enumerate(n1):
    j=idx2[-n-1]
    for k in range(d):
        U[(L+j)*d+k, i*d+k]=1       # summand1 -> summand2
        U[i*d+k, (L+j)*d+k]=1       # summand2 (m=-n-1) -> summand1 (e_{-m-1}=e_n)
Jp=lambda v: U@np.conj(v)
# antiunitary anticommutation: J' B J'^{-1} = -B  <=> U conj(B) U^T = -B
print("J'^2=1:",np.allclose(U@U,np.eye(dim)), "  J' B J'^-1 = -B:",np.allclose(U@np.conj(Bc)@U.T,-Bc))
P=np.diag((np.diag(Bc)>0).astype(float))
print("Basisprojektion J'P J'^-1 = 1-P:",np.allclose(U@P@U.T,np.eye(dim)-P))
lam=np.min(np.abs(np.diag(Bc)))
blk=np.where(np.isclose(np.abs(np.diag(Bc)),lam))[0]
print("lambda1 =",lam,"(=1/chi_seed in Bcov-Einheiten); Blockdim =",len(blk),
      "; Rang E+ =",int(sum(np.diag(Bc)[blk]>0)),", Rang E- =",int(sum(np.diag(Bc)[blk]<0)))
# real form W = Fix(J') on block, complex structure I = i(2P-1)|W
Pb=P[np.ix_(blk,blk)]; Ub=U[np.ix_(blk,blk)]
# real basis of Fix(J'): v + J'v, i(v - J'v) for v in E+
Ep=[b for b in range(len(blk)) if Pb[b,b]>0]
Wb=[]
for b in Ep:
    v=np.zeros(len(blk),complex); v[b]=1
    Wb.append(v+Ub@np.conj(v)); Wb.append(1j*(v-Ub@np.conj(v)))
Wb=np.array(Wb).T
print("dim_R W =",np.linalg.matrix_rank(np.vstack([Wb.real,Wb.imag])),
      "; J'-fix:",np.allclose(Ub@np.conj(Wb),Wb))
Iop=1j*(2*Pb-np.eye(len(blk)))
IW=Iop@Wb
coef=np.linalg.lstsq(Wb,IW,rcond=None)[0]
print("I bildet W in W ab (reelle Koeffizienten):",np.allclose(coef.imag,0)," I^2=-1:",np.allclose(coef@coef,-np.eye(coef.shape[0])),
      " orthogonal:",np.allclose(coef.real.T@coef.real,np.eye(coef.shape[0])))
# annulus compression C_A=(1+exp(2pi B))^-1 also basis covariance
CA=np.diag(1/(1+np.exp(2*np.pi*np.diag(Bc))))
print("Annulus-Kovarianz J'C J'^-1 = 1-C:",np.allclose(U@CA@U.T,np.eye(dim)-CA),
      "; Besetzung im lambda1-Block:",sorted(set(np.round(np.diag(CA)[blk],6))))
# single quarter: spectral asymmetry & eta
for al in [0.25,0.75]:
    eta=mp.zeta(0,al)-mp.zeta(0,1-al)
    print(f"eta(A_{al}) = {eta}")
print("eta(Bcov) =", (mp.zeta(0,0.25)-mp.zeta(0,0.75))+(mp.zeta(0,0.75)-mp.zeta(0,0.25)))
s1=set(np.round(E1/2,6)); print("Spec(A_1/4) symmetrisch unter Negation (Fenster):", all((-x in s1) for x in s1 if abs(x)<N/2))
 